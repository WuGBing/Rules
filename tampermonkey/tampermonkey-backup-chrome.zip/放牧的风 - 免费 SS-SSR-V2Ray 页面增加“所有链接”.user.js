// ==UserScript==
// @name        放牧的风 - 免费 SS/SSR/V2Ray 页面增加“所有链接”
// @description 直接提取放牧的风在页面上提供的链接。
// @namespace   UnKnown
// @match       https://www.youneed.win/free-ss
// @match       https://www.youneed.win/free-ssr
// @match       https://www.youneed.win/free-v2ray
// @version     1
// @grant       none
// ==/UserScript==

(() => {

  const       newNode =   document.createElement("div");
  const    parentNode =   document.querySelector('.context');
  const referenceNode = parentNode.querySelector(':scope > div');

  const protocolMap = new Map([
    ["ss"   , "ss"   ],
    ["ssr"  , "ssr"  ],
    ["v2ray", "vmess"]
  ]);
  const resultStr = Array.from(
    referenceNode.querySelectorAll(
      'table a[href^="' + protocolMap.get(
          location.pathname.slice(6)
        ) + '://"]'
    )
  ).map( a => a.href ).join("\n");

  // 元素

  // 所有链接
  const pre = document.createElement("pre");
  pre.style = "max-height: 12em; overflow-y: auto";
  pre.textContent = resultStr;

  // 复制按钮
  const button = document.createElement("button");
  button.style = "width: 100%; font-size: large";
  button.textContent = "复制全部链接";
  button.addEventListener("click", () => {
    try {
      if (navigator.clipboard) {
        navigator.clipboard.writeText(resultStr)
      } else {
        const eventCopyer = event => {
          event.preventDefault();
          event.clipboardData.setData("text/plain", resultStr);
        }
        document.addEventListener("copy", eventCopyer);
        document.execCommand("copy");
        document.removeEventListener("copy", eventCopyer);
      }
    } catch (error) {
      button.appendChild(str => {
        const info = document.createElement("pre");
        info.textContent ="若复制失败，请手动选择复制，" +
          "PC 端用户可按 F12 获取详细错误信息，以便反馈。"
         + "\n捕捉到的错误信息：" + str;
      })(error);
    }
  });

  newNode.id = "AllLinks";

  newNode.appendChild(pre);
  newNode.appendChild(button);

  parentNode.insertBefore(newNode, referenceNode);

})();