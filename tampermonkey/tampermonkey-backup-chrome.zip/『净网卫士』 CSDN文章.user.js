// ==UserScript==
// @author            Hunlongyu
// @name              『净网卫士』 CSDN文章
// @namespace         https://github.com/Hunlongyu
// @icon              https://i.loli.net/2019/04/22/5cbd720718fdb.png
// @description       只针对 CSDN 的文章，进行极致简化。移除了所有无关文章内容的元素。同时增加了：展开文章、剪贴板净化、代码一键复制功能。
// @version           0.1.3
// @include           *://*.csdn.net/*/article/details/*
// @grant             GM_addStyle
// @grant             GM_setClipboard
// @run-at            document-start
// @supportURL        https://gist.github.com/Hunlongyu/5c169b8ac288ca415e7068938a0fb47a
// @note              2019/06/20 v0.1.2 初始化,完成基础功能。
// @note              2019/06/21 v0.1.3 由原生的 js 复制到剪贴板，改为 GM 封装的。
// ==/UserScript==

(function() {
  'use strict';

  // 通过 css 净化文章页面。
  const pageCss = `
    /* 页面整体 */
    body{ background: #f5f6f7 !important; }
    iframe{ display: none !important; }

    /* 顶部菜单栏 */
    #csdn-toolbar{ display: none !important; }

    /* 左侧栏 */
    #mainBox aside{ display: none !important; }

    /* 主体 */
    #mainBox main{ width: 100% !important; }
    #article_content{ height: auto !important; }
    .hide-article-box{ display: none !important; }

    /* 右侧栏 */
    .recommend-fixed-box, .indexSuperise, .csdn-side-toolbar, .recommend-right, .bdsharebuttonbox, .widescreen-hide, .tool-box, .widescreen-more{ display: none !important; }

    /* 文章底部: 广告 + 留言 + 推荐 */
    #dmp_ad_58, .comment-box, .recommend-box{ display: none !important; }

    /* 遮罩 + 登录 */
    .login-mark, .login-box{ display: none !important; }
  `
  try {
    GM_addStyle(pageCss)
  } catch(e) {
    console.error('『净网卫士』 尝试净化页面失效，请反馈错误信息：', e)
  }

  // 净化剪贴板
  window.onload = function () {
    try {
      csdn.copyright.init('', '')
    } catch (e) {
      console.error('『净网卫士』 尝试净化剪贴板失效，请反馈错误信息：', e)
    }
  }

  // 代码复制功能
  const copyBtnCss = `
    .hljs-button{
      display: none !important;
      top: 0 !important;
      right: 0 !important;
      padding: 1px 10px !important;
      border-radius: 1px !important;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05) !important;
    }
  `
  const showCopyBtnCss = `
    .hljs-button{ display: block !important; }
  `
  try {
    GM_addStyle(copyBtnCss)
  } catch(e) {
    console.error('『净网卫士』 尝试修改复制按钮样式失败，请提交反馈。')
  }
  window.onload = function () {
    let copyBtns = document.querySelectorAll('.hljs-button')
    let codes = document.querySelectorAll('.prettyprint code')
    for (let i = 0; i < copyBtns.length; i++) {
      copyBtns[i].setAttribute('data-title', '复制')
      copyBtns[i].onclick = function () {
        let code = codes[i].innerText
        GM_setClipboard(code)
        copyBtns[i].setAttribute('data-title', '复制成功')
      }
    }
    try {
      GM_addStyle(showCopyBtnCss)
    } catch(e) {
      console.error('『净网卫士』 尝试显示复制按钮失败，请反馈错误信息：', e)
    }
  }
})()
