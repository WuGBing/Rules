// @require https://cdn.bootcss.com/jquery/2.2.4/jquery.min.js
function max_tb_search() {
    var new_search_addr = "http://www.zkq8.com/index.php?input=2&r=l&kw=" + $('.search-combobox-input').val();
    window.open(new_search_addr);
}

function max_stb_search() {
    var new_search_addr = "http://www.zkq8.com/index.php?input=2&r=l&kw=" + $('#J_Header_js').val();
    window.open(new_search_addr);
}

function max_tmall_search() {
    var new_search_addr = "http://www.zkq8.com/index.php?input=2&r=l&kw=" + $('.s-combobox-input').val();
    window.open(new_search_addr);
}

function max_get_json(data) {
	var n1 = data.indexOf("goodsItem");
	if (n1 < 0) return 0;
	var tmp_str = data.substr(n1);
	var n2 = tmp_str.indexOf(";");
	tmp_str=data.substr(n1+11,n2-11);
 
	return tmp_str;
}

function TINT(name) {
    var reTaoBao = /taobao.com/i;
    var reTmall = /tmall/i;
    var currentUrl = window.location.href;
    $('head').append($('<link rel="stylesheet" href="https://zkq8.com/zkq4tb.css">'));

    var h = 'https://zkq8.com/index.php?r=index/classify&kw=' + encodeURI(name);
    var init = "<div id='zkq_div'><table class='zkq_tab' id='zkq_table'><thead><tr><th><b onclick=window.open('https://link.zhihu.com/?target=https://www.zkq8.com') style='cursor:pointer'>\u4f18\u60e0\u5238</b></th><th>\u539f\u4ef7</th><th>\u5238\u540e\u4ef7</th><th>\u64cd\u4f5c\u261f</th></tr></thead><tbody><tr><td colspan='4'>\u6b63\u5728\u67e5\u8be2\u4f18\u60e0\u4fe1\u606f\uff0c\u8bf7\u7a0d\u5019...</td></tr></tbody></table></div>";
    $('#J_LinkBasket').parent().parent().prepend(init);
    $('.J_LinkAdd').parent().parent().prepend(init);
    if (reTaoBao.test(currentUrl)) {
        $('#zkq_table').addClass('zkq_tab_taobao');
    } else {
        $('#zkq_table').addClass('zkq_tab_tmall');
    }
    $.get(h,
    function(d, status) {
        $("#zkq_table tbody tr").remove();
		var reTaoBao = /taobao.com/i;
    var reTmall = /tmall/i;
    var currentUrl = window.location.href;
	var name='';
	if (reTaoBao.test(currentUrl)) {
	name = $('.tb-main-title').attr('data-title');
	} else {
	name= $('meta[name=keywords]').attr('content');	
	}
        var h= 'https://zkq8.com/index.php?r=index/classify&kw=' + encodeURI(name);
		var jso = max_get_json(d);
		var s =  JSON.parse(jso);
		if (s.length >0) {
			row += "<tr><td>" + s[0].quan_jine + "元</td><td>￥" + s[0].yuanjia + "</td><td>￥" + s[0].jiage + "</td><td><a style='display: inline-block;padding: 6px 9px;margin-bottom: 0;font-size: 16px;font-weight: normal;height:16px;line-height:16px;width:100px;text-align: center;white-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;cursor: pointer;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-image: none;border: 1px solid transparent;border-radius:2px;color: #fff;background-color: red;' href='" + h +  "' target='_blank'>领取</a></td></tr>";
		} else {
        var row = "<tr><td colspan='4'>\u8fd9\u4e2a\u5546\u54c1\u6ca1\u6709\u8d85\u503c\u4f18\u60e0\u5238</td></tr>";
		}
        $("#zkq_table tbody").append(row);
    });
}

(function() {
    'use strict';

    $(document).ready(function() {
        var idd = '';
        var name = ''; //$(document).attr('title');
        var host = window.location.host;
        if ($('#max-test').length <= 0) {
            if (host == 'detail.tmall.com') {
                idd = $("link[rel=canonical]").attr("href");
                idd = idd.split("id=")[1];
                name = $('meta[name=keywords]').attr('content');
                var tmall = '<div id="max-test"><p> <br/></p></div><div class="tb-action" style="margin-top:0"><a style="display: inline-block;padding: 6px 9px;margin-bottom: 0;font-size: 16px;font-weight: normal;height:16px;line-height:16px;width:100px;text-align: center;white-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;cursor: pointer;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-image: none;border: 1px solid transparent;border-radius:2px;color: #fff;background-color: #2e8b57;#2e8b57;" href="http://zkq8.com/index.php?r=index/classify&kw=' + encodeURI(name) + '&id=' + encodeURI(idd) + '" " target="_blank">优惠购买</a><a style="display: inline-block;padding: 6px 9px;margin-bottom: 0;font-size: 16px;font-weight: normal;height:16px;line-height:16px;width:100px;text-align: center;white-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;cursor: pointer;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-image: none;border: 1px solid transparent;border-radius:5px;color: #fff;background-color: #8600FF;#8600FF;margin-left:5px; " href="http://zkq8.com/index.php?r=p" target="_blank">疯抢榜TOP100</a><a style="display: inline-block;padding: 6px 9px;margin-bottom: 0;font-size: 16px;font-weight: normal;height:16px;line-height:16px;width:100px;text-align: center;white-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;cursor: pointer;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-image: none;border: 1px solid transparent;border-radius:5px;color: #fff;background-color: #2e8b57;#2e8b57;margin-left:5px; " href="http://zkq8.com/index.php?r=nine" target="_blank">9.9元包邮</a></div>';
                $('.tb-sku').append(tmall);
                TINT(name);
            } else if (host == 'item.taobao.com') {
                idd = $("link[rel=canonical]").attr("href");
                idd = idd.split("id=")[1];
                name = $('.tb-main-title').attr('data-title');
                var taobao = '<div id="max-test"><p> <br/></p></div><div class="tb-action" style="margin-top:0"><a style="display: inline-block;padding: 6px 9px;margin-bottom: 0;font-size: 16px;font-weight: normal;height:16px;line-height:16px;width:100px;text-align: center;white-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;cursor: pointer;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-image: none;border: 1px solid transparent;border-radius:2px;color: #fff;background-color: #2e8b57;#2e8b57;" href="http://zkq8.com/index.php?r=index/classify&kw=' + encodeURI(name) + '&id=' + encodeURI(idd) + '" " target="_blank">优惠购买</a><a style="display: inline-block;padding: 6px 9px;margin-bottom: 0;font-size: 16px;font-weight: normal;height:16px;line-height:16px;width:100px;text-align: center;white-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;cursor: pointer;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-image: none;border: 1px solid transparent;border-radius:5px;color: #fff;background-color: #8600FF;#8600FF;margin-left:5px; " href="http://zkq8.com/index.php?r=p" target="_blank">疯抢榜TOP100</a><a style="display: inline-block;padding: 6px 9px;margin-bottom: 0;font-size: 16px;font-weight: normal;height:16px;line-height:16px;width:100px;text-align: center;white-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;cursor: pointer;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-image: none;border: 1px solid transparent;border-radius:5px;color: #fff;background-color: #2e8b57;#2e8b57;margin-left:5px; " href="http://zkq8.com/index.php?r=nine" target="_blank">9.9元包邮</a></div>';
                $('.tb-key').append(taobao);
                TINT(name);
            } else if (host == 'detail.tmall.hk') {
                idd = $("link[rel=canonical]").attr("href");
                idd = idd.split("id=")[1];
                name = $('meta[name=keywords]').attr('content');
                var tmall_xg = '<div id="max-test"><p> <br/></p></div><div class="tb-action" style="margin-top:0"><a style="display: inline-block;padding: 6px 9px;margin-bottom: 0;font-size: 16px;font-weight: normal;height:16px;line-height:16px;width:100px;text-align: center;white-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;cursor: pointer;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-image: none;border: 1px solid transparent;border-radius:2px;color: #fff;background-color: #2e8b57;#2e8b57;" href="http://zkq8.com/index.php?r=index/classify&kw=' + encodeURI(name) + '&id=' + encodeURI(idd) + '" " target="_blank">优惠购买</a><a style="display: inline-block;padding: 6px 9px;margin-bottom: 0;font-size: 16px;font-weight: normal;height:16px;line-height:16px;width:100px;text-align: center;white-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;cursor: pointer;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-image: none;border: 1px solid transparent;border-radius:5px;color: #fff;background-color: #8600FF;#8600FF;margin-left:5px; " href="http://zkq8.com/index.php?r=p" target="_blank">疯抢榜TOP100</a><a style="display: inline-block;padding: 6px 9px;margin-bottom: 0;font-size: 16px;font-weight: normal;height:16px;line-height:16px;width:100px;text-align: center;white-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;cursor: pointer;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-image: none;border: 1px solid transparent;border-radius:5px;color: #fff;background-color: #2e8b57;#2e8b57;margin-left:5px; " href="http://zkq8.com/index.php?r=nine" target="_blank">9.9元包邮</a></div>';
                $('.tb-sku').append(tmall_xg);
				TINT(name);
            } else if (host == 'chaoshi.detail.tmall.com') {
                idd = $('a[id=J_AddFavorite]').attr('data-aldurl');
                idd = idd.split("idd=")[1];
                name = $('input[name=title]').attr('value');
                var cs_tmall = '<div id="max-test"><p> <br/></p></div><div class="tb-action tb-btn-add tb-btn-sku"><a style="display: inline-block;padding: 6px 9px;margin-bottom: 0;font-size: 16px;font-weight: normal;height:16px;line-height:16px;width:100px;text-align: center;white-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;cursor: pointer;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-image: none;border: 1px solid transparent;border-radius:5px;color: #fff;background-color: #2e8b57;#2e8b57;"href="http://zkq8.com/index.php?r=index/classify&kw=' + encodeURI(name) + '&id=' + encodeURI(idd) + '" " target="_blank">优惠购买</a><a style="display: inline-block;padding: 6px 9px;margin-bottom: 0;font-size: 16px;font-weight: normal;height:16px;line-height:16px;width:100px;text-align: center;white-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;cursor: pointer;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-image: none;border: 1px solid transparent;border-radius:5px;color: #fff;background-color: #8600FF;#8600FF;margin-left:5px; " href="http://zkq8.com/index.php?r=p" target="_blank">疯抢榜TOP100</a><a style="display: inline-block;padding: 6px 9px;margin-bottom: 0;font-size: 16px;font-weight: normal;height:16px;line-height:16px;width:100px;text-align: center;white-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;cursor: pointer;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-image: none;border: 1px solid transparent;border-radius:5px;color: #fff;background-color: #2e8b57;#2e8b57;margin-left:5px; " href="http://zkq8.com/index.php?r=nine" target="_blank">9.9元包邮</a></div>';
                $('.tb-sku').append(cs_tmall);
            }
        }

        if ($('#max-search').length <= 0) {
            if (host == 'www.taobao.com') {
                var tb_search = '<div id="max-search" style="position: absolute;right: -100px;top: 22px;width: 100px;height: 40px;text-align: center;line-height: 40px;border-radius: 9px;color: #ffffff;background: #FF4200;font-size: 16px;font-weight: 800;"><a id="max-search-a" style="color:white;" href="javascript:void(0);">搜优惠券</a></div>';
                $('.search-bd').append(tb_search);
                $('#max-search-a').click(function() {
                    max_tb_search()
                })
            } else if (host == 's.taobao.com') {
                var stb_search = '<div style="float:right;margin-top:1px;color: #ffffff;background: #FF4200;font-size: 16px;font-weight: 800;width: 130px;height: 30px;text-align: center;line-height: 30px;border-radius: 9px;" id="max-search"><a id="max-search-a" style="color:white;" href="javascript:void(0);">搜优惠券</a></div>';
                $('.search').append(stb_search);
                $('#max-search-a').click(function() {
                    max_tb_search()
                });
            } else if (host == 'www.tmall.com' || host == 'list.tmall.com') {
                var tmall_search = '<div style="float:right;margin-top:1px;color: #ffffff;background: #FF4200;font-size: 16px;font-weight: 800;width: 130px;height: 30px;text-align: center;line-height: 30px;border-radius: 9px;" id="max-search"><a id="max-search-a" style="color:white;" href="javascript:void(0);">搜优惠券</a></div>';
                $('#mallSearch').append(tmall_search);
                $('#max-search-a').click(function() {
                    max_tmall_search()
                });
            }
        }

    });
})()