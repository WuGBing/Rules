// ==UserScript==
// @name         百度网盘解析下载跳转按钮
// @version      0.0.1
// @description  百度网盘分享链接页面增加按钮，用于跳转。
// @match        *://pan.baidu.com/s/*
// @match        *://pan.baidu.com/share/*
// @match        *://yun.baidu.com/s/*
// ==/UserScript==

(function() {
    'use strict';
    function addDiv(){
        var div = document.createElement("div");
        div.innerHTML = "直链在线解析";
        var css = "position:fixed;top:116px;left:240px;z-index:999999999;width:100px;height:30px;line-height:30px;text-align:center;font-size:12px;background:#fff;font-family:Verdana, Arial, '宋体';font-weight:500;color:#09aaff;user-select:none;padding:0px;white-space:nowrap;border-radius:3px;border:0.5px solid #09aaff;cursor:pointer;";
        div.style.cssText = css;
        if(window.self === window.top){ document.body.appendChild(div);}
        div.addEventListener("click",function(){
            let url = window.location.href;
            url = url.replace('baidu.com','baidusu.com');
            window.open(url, "_blank");});
   }
   addDiv();
})();




(function() {
    'use strict';
    function addDiv2(){
        var div = document.createElement("div2");
        div.innerHTML = "PD网页版";
        var css = "position:fixed;top:116px;left:355px;z-index:999999999;width:100px;height:30px;line-height:30px;text-align:center;font-size:12px;background:#fff;font-family:Verdana, Arial, '宋体';font-weight:500;color:#09aaff;user-select:none;padding:0px;white-space:nowrap;border-radius:3px;border:0.5px solid #09aaff;cursor:pointer;";
        div.style.cssText = css;
        if(window.self === window.top){ document.body.appendChild(div);}
        div.addEventListener("click",function(){
            let url = window.location.href;
            url = url.replace('baidu.com','baiduwp.com');
            window.open(url, "_blank");});
   }
   addDiv2();
})();
