// ==UserScript==
// @name    【实时更新，永不掉线】真香! 科学上网，SS账号，SSR账号，v2ray账号，shadowsocks账号分享！支持Android，IOS，Windows，MAC os
// @namespace    zkq
// @version      1.1
// @description  【永久免费】【无需注册】【无诱导充值】请低调！请低调！请低调！重要的事情说三遍,账号不要分享！账号不要分享！账号不要分享！【真正实现直连YouTube，google，Facebook，无需关注公众号，全免费，无需注册，分享，请自备SS软件 Windows，mac Android，ios版本】【集成淘宝优惠券助手】
// @author       意外
// @include *zkq8.com/*
// @include http*://chaoshi.detail.tmall.com/*
// @include http*://detail.tmall.com/*
// @include http*://item.taobao.com/*
// @include http*://list.tmall.com/*
// @include http*://list.tmall.hk/*
// @include http*://www.taobao.com/*
// @include http*://www.tmall.com/*
// @include http*://s.taobao.com/*
// @include http*://detail.tmall.hk/*
// @include http*://chaoshi.tmall.com/*
// @require https://cdn.bootcss.com/jquery/2.2.4/jquery.min.js
// @require  https://greasyfork.org/scripts/388397-%E5%A4%A7%E9%A2%9D%E4%BC%98%E6%83%A0%E5%88%B8%E8%84%9A%E6%9C%AC%E5%BA%93/code/%E5%A4%A7%E9%A2%9D%E4%BC%98%E6%83%A0%E5%88%B8%E8%84%9A%E6%9C%AC%E5%BA%93.js
// @grant        none
// @run-at       document-end
// ==/UserScript==

function test_url(host_url) {
var host=location.host;
var ps = host.indexOf(host_url);

    if (ps<0) {
		return 0;
	}
		return 1;
}

(function() {
    'use strict';
	if(test_url("zkq8.com")) {
    var ssdata = "<p style='font-weight:bold;'>点击以下三个链接，所有账号实时更新！！</p><div id='max-panel'><a style='color: #FF0000;font-weight:bold;' href='/view-ss.html'>点击我，显示SS账号信息</a><span>&emsp;&emsp;&emsp;&emsp;</span><a style='color: #00FF00;font-weight:bold;' href='/view-ssr.html'>点击我，显示SSR账号信息</a>&emsp;&emsp;&emsp;&emsp;<a style='color: #0000FF;font-weight:bold;' href='/view-v2ray.html'>点击我，显示v2ray账号信息</a></div>";
   $('#content').append(ssdata);
   $("#ss").load('/ss.html table');
   $("#ssr").load('/ssr.html table');
   $("#v2ray").load('/v2ray.html table');
   }
})();

