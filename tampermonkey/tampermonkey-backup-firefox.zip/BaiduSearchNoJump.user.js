// ==UserScript==
// @name         BaiduSearchNoJump
// @namespace    https://github.com/ywzhaiqi
// @authuer      ywzhaiqi
// @description  This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @include      http://www.baidu.com/*
// @include      https://www.baidu.com/*
// @homepageURL  https://greasyfork.org/scripts/1771/

// updateURL     https://userscripts.org/scripts/source/161812.meta.js
// downloadURL   https://userscripts.org/scripts/source/161812.user.js
// @version      2014.11.19.1
// @grant        GM_xmlhttpRequest
// @run-at       document-end
// @note         2014-08-19，小幅调整
// @note         2014-07-23，增加新的链接选择器 a[href^="//www.baidu.com/link?url="]
// @note         2014-06-10，放弃原服务器解析的方法，改用 HEAD 方式。
// @note         2014-05-28，增加对百度不刷新页面的支持
// @note         2014-05-24，增加对翻页脚本的支持
// ==/UserScript==
