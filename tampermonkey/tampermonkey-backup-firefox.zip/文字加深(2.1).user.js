// ==UserScript==
// @name 文字加深(2.1)
// @namespace Violentmonkey Scripts
// @match *://*/*
// @grant none
// ==/UserScript==

(function() {

        function grayElem(elem) {   //将元素变灰
        let elemStyle = window.getComputedStyle(elem);
        if (!elemStyle) {
            return;
        }
        let rgbaValues = elemStyle.getPropertyValue('color').match(/\d+(\.\d+)?/g);
        if (rgbaValues) {

            var _xis = 0.65;  //文字调整系数，可自行调整
            let [red, green, blue, alpha] = rgbaValues;
           var darkness = 0.299 * red + 0.587 * green + 0.114 * blue ; //引进颜色深浅判断公式
          if ( darkness >= 245){           //排除深背景白（浅）文字情况
          return ("rgb(250, 250, 250)");}
         else {
            if  ( darkness <= 170) {
              var _xis = 0.9;}      //也可直接RETURN返回
//             return; }
            //将文字颜色从两端向85按比例压缩，可同时稍调亮黑色
            elem.style.setProperty('color', (alpha ? 'rgba(' : 'rgb(') +

               Math.round(85 + (red - 85) * _xis) + ', ' +
               Math.round(85 + (green - 85) * _xis) + ', ' +
               Math.round(85 + (blue - 85) * _xis) +
            (alpha ? (', ' + alpha + ')') : ')'), 'important');
         }
        }
    }
    function grayColor() {
        for (let elem of document.getElementsByTagName('*')) {
            grayElem(elem);
        }
        (new MutationObserver(mutations => {
            for (let mutation of mutations) {
                for (let elem of mutation.addedNodes) {
                    if (elem.nodeType == 1) {   //元素节点
                        grayElem(elem);
                        for (let childNode of elem.getElementsByTagName('*')) {   //遍历所有子节点
                            grayElem(childNode);
                        }
                    }
                }
            }
        })).observe(document, {
            childList: true,
            subtree: true
        });
    }
     grayColor();
})();

