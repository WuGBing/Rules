// ==UserScript==
// @name         虎牙精简
// @namespace G-uang
// @version       2019.10.20
// @description 提供简洁的界面，只为安心看直播。
// @author       G-uang
// @match        *://*.huya.com/*
// ==/UserScript==


(function () {
   let css = '{display:none !important;height:0 !important}'

   css += '#J-weekRank{display:none !important;}'
   css += '#chatRoom{height:100% !important;}'
   css += '#chatRoom > div{height:81% !important;}'
   css += '.room-footer{display:none !important;}'
   css += '#J_profileNoticeText{display:none;}'
   css += '#J_chatFansBadge{display:none !important;}'
   css += '#J-room-chat-color{display:none !important;}'
   css += '#share-entrance{display:none !important;}'
   css += '#J_hySide{display:none !important;}'
   css += '#hy-nav-download{display:none !important;}'
   css += '#player-gift-wrap{display:none !important;}'
   css += '#wrap-notice{display:none !important;}'
   css += '#wrap-income{display:none !important;}'
   css += '#J_roomGgTop{display:none !important;}'
   css += '#J_adCategory{display:none !important;}'
   css += '#avatar-img{display:none !important;}'
   css += '#banner-ab{display:none !important;}'

   loadStyle(css)
   function loadStyle(css) {
      var style = document.createElement('style')
      style.type = 'text/css'
      style.rel = 'stylesheet'
      style.appendChild(document.createTextNode(css))
      var head = document.getElementsByTagName('head')[0]
      head.appendChild(style)
   }
})()