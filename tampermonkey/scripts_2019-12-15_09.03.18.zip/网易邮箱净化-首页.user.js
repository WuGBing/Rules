// ==UserScript==
// @name         网易邮箱净化-首页
// @namespace    https://greasyfork.org/users/158180
// @version      0.1
// @description  净化网易系邮箱首页
// @author       Shiyunjin
// @match        http*://mail.163.com/js6/main.jsp*
// @match        http*://mail.126.com/js6/main.jsp*
// @match        http*://mail.yeah.net/js6/main.jsp*
// @grant        none
// ==/UserScript==

var $S = function(a, b) {
    Session.set("isFree",false);
    Session.set("isVip", true);
    Session.set("ad",{show: false, showClose: false, userType: "ud"});
    if (2 == arguments.length) return Session.set(a, b);
    var c = Session.get(a);
    return c
}

(function() {
    'use strict';

    // Your code here...
})();