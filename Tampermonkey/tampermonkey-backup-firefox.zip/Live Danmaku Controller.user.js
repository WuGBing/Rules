// ==UserScript==
// @name                Live Danmaku Controller
// @name:zh-CN          直播弹幕控制
// @description         Auto turn off live danmaku.
// @description:zh-CN   自动关闭直播弹幕.
// @namespace           live-danmaku-controller
// @version             2019.12.01
// @author              Akatsuki
// @license             MIT License
// @grant               GM_info
// @run-at              document-idle
// @require             https://cdn.jsdelivr.net/npm/jquery@3.4.1/dist/jquery.min.js
// @require             https://greasyfork.org/scripts/48306-waitforkeyelements/code/waitForKeyElements.js?version=275769
// @match               *://live.bilibili.com/*
// @match               *://www.douyu.com/*
// @match               *://www.huya.com/*
// @match               *://www.yy.com/*
// ==/UserScript==

'use strict'

var selector = {
  'live.bilibili.com': {
    'on': "i[class='live-icon-danmaku-on']",
    'off': "i[class='live-icon-danmaku-off']"
  },
  'www.douyu.com': {
    'on': "div[class^='showdanmu-']:not([class*='removed-'])",
    'off': "div[class^='hidedanmu-']:not([class*='removed-'])"
  },
  'www.huya.com': {
    'on': "div[class='danmu-show-btn'][title='关闭弹幕']",
    'off': "div[class='danmu-show-btn danmu-hide-btn'][title='开启弹幕']"
  },
  'www.yy.com': {
    'on': "div[class~='yc__bullet-comments-btn'][title='关闭弹幕']",
    'off': "div[class~='yc__bullet-comments-btn'][title='打开弹幕']"
  }
}

var delay_site = [
  'www.yy.com'
]

var live_site = document.location.hostname

// Auto turn off danmaku
function disable_danmaku(button) {
  button[0].click()
}

function disable_danmaku_delay() {
  var button = document.querySelector(selector[live_site].on)
  if (button !== null) {
    button.click()
  }
}

if (delay_site.includes(live_site)) {
  setTimeout(disable_danmaku_delay, 10000)
} else {
  waitForKeyElements(selector[live_site].on, disable_danmaku, false)
}
