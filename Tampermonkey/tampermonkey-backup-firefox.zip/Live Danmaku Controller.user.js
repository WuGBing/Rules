// ==UserScript==
// @name                Live Danmaku Controller
// @name:zh-CN          直播弹幕控制
// @description         Auto turn off danmaku, (And press 'M' to control danmaku on/off)[Temporarily remove].
// @description:zh-CN   自动关闭弹幕, (按下 'M' 随时开关直播弹幕)[暂时删除].
// @namespace           live-danmaku-controller
// @version             2019.09.25
// @author              Akatsuki
// @license             MIT License
// @inject-into         content
// @run-at              document-idle
// @require             https://cdn.jsdelivr.net/npm/jquery@3.4.1/dist/jquery.min.js
// @require             https://greasyfork.org/scripts/48306-waitforkeyelements/code/waitForKeyElements.js?version=275769
// @match               *://live.bilibili.com/*
// @match               *://www.douyu.com/*
// @match               *://www.huya.com/*
// @match               *://www.yy.com/*
// ==/UserScript==

'use strict'

var selector = {
  'live.bilibili.com': {
    'on': "i[class='live-icon-danmaku-on']",
    'off': "i[class='live-icon-danmaku-off']"
  },
  'www.douyu.com': {
    'on': "div[class^='showdanmu-']:not([class*='removed-'])",
    'off': "div[class^='hidedanmu-']:not([class*='removed-'])"
  },
  'www.huya.com': {
    'on': "div[class='danmu-show-btn'][title='关闭弹幕']",
    'off': "div[class='danmu-show-btn danmu-hide-btn'][title='开启弹幕']"
  },
  'www.yy.com': {
    'on': "div[class~='yc__bullet-comments-btn'][title='关闭弹幕']",
    'off': "div[class~='yc__bullet-comments-btn'][title='打开弹幕']"
  }
}

var delay_site = [
  'www.yy.com'
]

var live_site = document.location.hostname

// Auto turn off danmaku

function disable_danmaku(button) {
  button[0].click()
}

function disable_danmaku_delay() {
  var button = document.querySelector(selector[live_site].on)
  if (button !== null) {
    button.click()
  }
}

if (delay_site.includes(live_site)) {
  setTimeout(disable_danmaku_delay, 10000)
} else {
  waitForKeyElements(selector[live_site].on, disable_danmaku, false)
}

/* Temporarily remove control_danmaku function

// Detect 'm' and 'M' key and control danmaku on/off

function control_danmaku(button) {
  if (document.querySelector(button.on) !== null) {
    // on -> off
    document.querySelector(button.on).click()
  } else if (document.querySelector(button.off) !== null) {
    // off -> on
    document.querySelector(button.off).click()
  }
}

$(document).keypress(function (key) {
  // detect 'm' or 'M' Key
  if (key.which === 77 || key.which === 109) {
    control_danmaku(selector[live_site])
  }
})

*/
