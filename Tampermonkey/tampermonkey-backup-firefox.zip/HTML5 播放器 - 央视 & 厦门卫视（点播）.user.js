// ==UserScript==
// @name       HTML5 播放器 / 央视 & 厦门卫视（点播）
// @name:en    HTML5 Player for CCTV & XMTV
// @author     Hokkian
// @namespace  https://github.com/hokkian
// @description 央视网和厦门广电网播放器替换为 HTML5 播放器（DPlayer），目前已支持大部分页面。
// @description:en For CCTV.com / CNTV.CN / XMTV.CN 
// @version    1.0
// @match      http*://*.xmtv.cn/*shtml
// @match      http*://*.cntv.cn/*shtml
// @match      http*://*.cctv.com/*shtml
// @match      http*://*.*.cctv.com/*shtml
// @require    https://cdn.jsdelivr.net/npm/hls.js@latest
// @require    https://cdn.jsdelivr.net/npm/dplayer@latest/dist/DPlayer.min.js
// @resource DPCSS https://cdn.jsdelivr.net/npm/dplayer@latest/dist/DPlayer.min.css
// @grant GM_getResourceText
// @grant GM_addStyle
// ==/UserScript==

function getGuid() {
  // Get GUID (a 32 character string)
  // 一般只有一个 GUID
  // 偶有视频拥有多个 GUID e.g. m.news.cctv.com/2019/10/13/ARTIC0os50JcJ8dcDuGyHWUM191013.shtml 
  var guid = [];
  var xhr = new XMLHttpRequest(),
          method = "GET",
          url = document.documentURI.match(/http[^\?]+/)[0];

  xhr.open(method, url, false);
  xhr.onreadystatechange = function () {
    if(xhr.readyState === 4 && xhr.status === 200) {

      var re = /var\s+guid_*\d*\s*=\s*"([A-Za-z0-9]{32})";/g; // var guid="298af38881c049999dbeec5dc3cab57a"; // var guid_0="298af38881c049999dbeec5dc3cab57a";
      var sourcecode = xhr.responseText;
      var tmpGuid = null;

      while( res = re.exec(sourcecode)) {
          guid.push(res[1]);
      }

      tmpGuid = sourcecode.match(/"videoCenterId"\s*,\s*"([A-Za-z0-9]{32})"/); // "videoCenterId","be153a817c2e4b1181183d7fd8879e92"
      if ( guid.length == 0 && tmpGuid != null) {
          guid.push(tmpGuid[1]);
      }
      tmpGuid = sourcecode.match(/videoCenterId\s*:\s*"([A-Za-z0-9]{32})"/); // videoCenterId: "ed7f4d3b2ba24e9f8713569a89fb9d7e"
      if ( guid.length == 0 && tmpGuid != null) {
          guid.push(tmpGuid[1]);
      }
      tmpGuid = sourcecode.match(/var\s+video_guid\s*=\s*"([A-Za-z0-9]{32})";/); //var video_guid = "88884dd98a2e425abe8424bc5a1e7984";
      if ( guid.length == 0 && tmpGuid != null) {
          guid.push(tmpGuid[1]);
      }
    }
  };
  xhr.send();
  console.log(guid);
  console.log('guid length ' + guid.length );
  return guid;
}

function generateM3U8(guid) {
  var videoUrl = []; 

  const SERVER_ARRAY = ['http://hls.cntv.myalicdn.com', 'http://hls.cntv.kcdnvip.com']; // 末尾无 slash
  var server = SERVER_ARRAY[Math.floor((Math.random()*SERVER_ARRAY.length))]

  videoUrl[0] = `${server}/asp/hls/450/0303000a/3/default/${guid}/450.m3u8`;
  videoUrl[1] = `${server}/asp/hls/850/0303000a/3/default/${guid}/850.m3u8`; 
  videoUrl[2] = `${server}/asp/hls/1200/0303000a/3/default/${guid}/1200.m3u8`;
  videoUrl[3] = `${server}/asp/hls/2000/0303000a/3/default/${guid}/2000.m3u8`;

  console.log(videoUrl);
  return videoUrl;
}

function createDPlayer(containerId, videoUrl, defaultQuality) {
          const dp = new DPlayer({
          container: document.getElementById(containerId),
          // autoplay: true,
          // screenshot: true,
          theme: '#FADFA3',
          lang: 'zh-cn',
          video: {
            quality: [
                    {
                        name: '流畅',
                        url: videoUrl[0],
                        type: 'hls',
                    },
                    {
                        name: '标清',
                        url: videoUrl[1],
                        type: 'hls',
                    },
                    {
                        name: '高清',
                        url: videoUrl[2],
                        type: 'hls',
                    },
                    {
                        name: '超清',
                        url: videoUrl[3],
                        type: 'hls',
                    },
                ],
                defaultQuality: defaultQuality,
          },
          pluginOptions: {
              hls: {
                  // hls config
              },
          },
          contextmenu: [
              {
                  text: '\u2764 Hokkian',
                  link: 'https://github.com/hokkian',
              },
          ],
        });
}

(function(){

  // Load CSS file
  var DPlayerCSS = GM_getResourceText('DPCSS');
  GM_addStyle(DPlayerCSS);

  var guids = getGuid(); // 可能有多个 GUID
  var guid = null;
  // console.log('guid length ' + guids.length );
  
  if ( guids.length == 0 ) {
    console.log('没有 GUID');
    return;
  } else if ( guids.length == 1 ){
      guid = guids[0];

      var videoUrl = []; // 点播
      var defaultQuality = 0;

      videoUrl = generateM3U8(guid);

      // Hide Useless Elements
      // Video Containerv
      var host = window.location.host;
      if ( host.includes('xmtv.cn')) {
        defaultQuality = 0; // 非央视默认只有流畅
        if ( host.startsWith('tv') ) {
            $('#myFlash').before("<div id=\"dplayer\" style=\"margin: 0 auto; width: 854px; height: 480px;\"></div>");
            $('#myFlash').hide();
        } else {
            $('#myFlash').before("<div id=\"dplayer\" style=\"margin: 0 auto; width: 640px; height: 480px;\"></div>");
            $('#myFlash').hide();
        }
      } else if ( window.location.host.includes('cctv') || window.location.host.includes('cntv') ) {
        defaultQuality = 3; // 央视高清
        if ( $('.nr_1').length ) {
            $('.video').empty();
            $('.video').prepend("<div id=\"dplayer\" style=\"margin: 0 auto; width: 1000px; height: 563px;\"></div>"); // width: 1000px; height: 563px; width: auto; height: 100%;
        } else if ( $('#myFlash').length && !$('#kuaikanvideo').length ) {
            var width = 0, height = 0;
            width = ( $('#myFlash img').attr('width') != null ) ? $('#myFlash img').attr('width') : '540';
            height = ( $('#myFlash img').attr('height') != null ) ? $('#myFlash img').attr('height') : '400';
            $('#myFlash').before(`<div id="dplayer" style="margin: 0 auto; width: ${width}px; height: ${height}px;"></div>`); 
            $('#myFlash').hide();
        } else if ( $('#_video').length ) {
            // http://v.cctv.com/2018/01/11/VIDEmR5QuhZQM3mbxVKkhBU9180111.shtml
            $('#_video').before(`<div id="dplayer" style="margin: 0 auto; width: 940px; height: 529px;"></div>`); 
            $('#_video').hide();
        } else if ( $('#player').length ) {
            var width = null, height = null;
            width = ( document.getElementById('_video').style.width != null ) ? document.getElementById('_video').style.width : '940px';
            height = ( document.getElementById('_video').style.height != null ) ? document.getElementById('_video').style.height : '529px';
            // console.log(`${width} / ${height}`);
            $('#player').before("<div id=\"dplayer\" style=\"margin: 0 auto; width: 1000px; height: 582px;\"></div>"); 
            $('#player').hide();
        } else if ( $('#kuaikanvideo').length ) { 
            // http://news.cctv.com/2019/10/11/ARTIbrrj8yfXp1UFYvAow14W191011.shtml
            $('#kuaikanvideo').empty();
            $('#kuaikanvideo').prepend("<div id=\"dplayer\" style=\"margin: 0 auto; width: 1000px; height: 613px;\"></div>"); 
            // $('.kuaikanvideo').hide();
        } else if ( $('#embed_playerid').length ) {
            // https://greasyfork.org/zh-CN/forum/discussion/35076/x
            // http://sannong.cctv.com/2018/03/09/ARTIWqXxSuWVDG17gOya9YAp180309.shtml
            $('#embed_playerid').hide();
            $('#embed_playerid').before("<div id=\"dplayer\" style=\"margin: 0 auto; width: 540px; height: 400px;\"></div>"); 
        }
      } 
      var containerId = 'dplayer';
      createDPlayer(containerId, videoUrl, defaultQuality);
  } else {
    console.log('多个 GUID');
    var videoUrl = []; 
    var defaultQuality = 3;
    for (let i =0, len = guids.length; i < len; i++) {
      $(`#flash_${i}`).hide();
      $(`#flash_${i}`).before(`<div id="dplayer_${i}" style="margin: 0 auto; width: 540px; height: 400px;"></div>`); 
      var containerId = `dplayer_${i}`;
      videoUrl = generateM3U8(guids[i]);
      createDPlayer(containerId, videoUrl, defaultQuality);
    }
  }

})();
