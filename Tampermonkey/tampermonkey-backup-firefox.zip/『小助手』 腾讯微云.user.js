// ==UserScript==
// @author            Hunlongyu
// @name              『小助手』 腾讯微云
// @namespace         https://github.com/Hunlongyu
// @icon              https://i.loli.net/2019/04/22/5cbd720718fdb.png
// @description       新增一键磁力离线下载按钮。
// @version           0.0.1
// @include           *://www.weiyun.com/*
// @grant             GM_addStyle
// @grant             GM.setClipboard
// @run-at            document-end
// @supportURL        https://gist.github.com/Hunlongyu/2d7cc7db66b79831c3af23cc52a85845
// ==/UserScript==

(function() {
    'use strict'

    let div = document.createElement('div')
    let html = `
      <div class="action-item">
        <div class="action-item-con">
          <span class="act-txt">一键离线</span>
        </div>
      </div>
    `
    div.innerHTML = html
    div.setAttribute('class', 'mod-action-wrap clearfix mod-action-wrap-a')

    window.onload = function() {
        let nav = document.querySelector('.mod-nav')
        nav.appendChild(div)
        div.addEventListener('click', function() {
          document.querySelectorAll('li.menu-item')[8].click()
          document.querySelectorAll('.tab-nav-item')[1].click()
          setTimeout(function() {
              document.querySelector('.input-block').focus()
          }, 10)
        }, false)
    }
})()