// ==UserScript==
// @author            Hunlongyu
// @name              『净网卫士』 CSDN文章
// @namespace         https://github.com/Hunlongyu
// @description       This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @version           0.1.3.1
// @include           *://*.csdn.net/*/article/details/*
// @grant             GM_addStyle
// @grant             GM_setClipboard
// @run-at            document-start
// @supportURL        https://gist.github.com/Hunlongyu/5c169b8ac288ca415e7068938a0fb47a
// @note              2019/06/20 v0.1.2 初始化,完成基础功能。
// @note              2019/06/21 v0.1.3 由原生的 js 复制到剪贴板，改为 GM 封装的。
// ==/UserScript==
