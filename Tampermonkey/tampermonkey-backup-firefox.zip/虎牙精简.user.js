// ==UserScript==
// @name         虎牙精简
// @namespace G-uang
// @version       2019.12.11
// @description 提供简洁的界面，只为安心看直播。
// @author       G-uang
// @match        *://*.huya.com/*
// ==/UserScript==


(function () {
   let css = '{display:none !important;height:0 !important}'

   css += '#J-weekRank{display:none !important;}'
   css += '#chatRoom{height:100% !important;}'
   css += '#chatRoom > div{height:81% !important;}'
   css += '.room-footer{display:none !important;}'
   css += '#J_profileNotice{display:none !important;}'
   css += '#J_chatFansBadge{display:none !important;}'
   css += '#J-room-chat-color{display:none !important;}'
   css += '#share-entrance{display:none !important;}'
   css += '#J_hySide{display:none !important;}'
   css += '#hy-nav-download{display:none !important;}'
   css += '#player-gift-wrap{display:none !important;}'
   css += '#wrap-notice{display:none !important;}'
   css += '#wrap-income{display:none !important;}'
   css += '#J_roomGgTop{display:none !important;}'
   css += '#J_adCategory{display:none !important;}'
   css += '#avatar-img{display:none !important;}'
   css += '#banner-ab{display:none !important;}'
   css += '#huya-ab > div.banner-ab-warp > div.ab-close-btn:last-child{display:none !important;}'
   css += '#chat-room__list > li.J_msg:first-child > p{display:none !important;}'
   css += '#duya-header > div.duya-header-wrap.clearfix > div.duya-header-bd.clearfix > div.duya-header-ad:last-child > a.duya-header-ad-link.j_duya-header-ad > img.duya-header-ad-img{display:none !important;}'
   css += '#main_col > div.room-backToTop.j_room-backToTop:last-child{display:none !important;}'
   css += '#J_playerMain > div.room-player-gift-placeholder:first-child{display:none !important;}'
   css += '#J_roomHeader > div.room-hd-r:last-child > div.host-control.J_roomHdCtrl > div.jump-to-phone:nth-child(4){display:none !important;}'
   css += '#matchMain > div.diy-comps-wrap{display:none !important;}'
   css += '#J_spbg{display:none !important;}'
   
   loadStyle(css)
   function loadStyle(css) {
      var style = document.createElement('style')
      style.type = 'text/css'
      style.rel = 'stylesheet'
      style.appendChild(document.createTextNode(css))
      var head = document.getElementsByTagName('head')[0]
      head.appendChild(style)
   }
})()

//m开关弹幕
'use strict';
var selector = {
   "www.huya.com": {
      "on": "div[class='danmu-show-btn'][title='关闭弹幕']",
      "off": "div[class='danmu-show-btn danmu-hide-btn'][title='开启弹幕']"},};
var live_site = document.domain;
function danmaku_switcher(player) {
   if (document.querySelector(player.on) != null) {
      document.querySelector(player.on).click();}
   else if (document.querySelector(player.off) != null) {
      document.querySelector(player.off).click();}};
$(document).keypress(function(key) {
   if (key.which === 77 || key.which === 109) {
      danmaku_switcher(selector[live_site]);}});