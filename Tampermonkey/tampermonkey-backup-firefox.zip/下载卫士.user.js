// ==UserScript==
// @name         下载卫士
// @namespace    http://www.newday.me/
// @version      0.1.5
// @icon         http://www.newday.me/xia/favicon.ico
// @author       哩呵
// @description  拒绝高(捆)速(绑)下载
// @match        *://*.onlinedown.net/*
// @match        *://*.cr173.com/*
// @match        *://*.xiazaiba.com/*
// @match        *://*.mydown.com/*
// @match        *://*.pc6.com/*
// @match        *://*.zol.com.cn/*
// @match        *://*.pconline.com.cn/*
// @match        *://*.jb51.net/*
// @match        *://*.cncrk.com/*
// @match        *://pc.qq.com/*
// @match        *://*.crsky.com/*
// @match        *://*.duote.com/*
// @match        *://*.downza.cn/*
// @match        *://*.yesky.com/*
// @match        *://*.ddooo.com/*
// @match        *://*.pchome.net/*
// @match        *://*.xpgod.com/*
// @match        *://*.52z.com/*
// @match        *://*.opdown.com/*
// @match        *://*.newday.me/*
// @connect      newday.me
// @require      https://cdn.staticfile.org/jquery/1.12.4/jquery.min.js
// @require      https://cdn.staticfile.org/vue/2.6.6/vue.min.js
// @run-at       document-start
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_listValues
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function () {
    'use strict';

    var injectConfig = {
        name: "xzws",
        version: "0.1.5"
    };

    var container = (function () {
        var obj = {
            module_defines: {},
            module_objects: {}
        };

        obj.define = function (name, requires, callback) {
            name = obj.processName(name);
            obj.module_defines[name] = {
                requires: requires,
                callback: callback
            };
        };

        obj.require = function (name, cache) {
            if (typeof cache == "undefined") {
                cache = true;
            }

            name = obj.processName(name);
            if (cache && obj.module_objects.hasOwnProperty(name)) {
                return obj.module_objects[name];
            }
            else if (obj.module_defines.hasOwnProperty(name)) {
                var requires = obj.module_defines[name].requires;
                var callback = obj.module_defines[name].callback;

                var module = obj.use(requires, callback);
                cache && obj.register(name, module);
                return module;
            }
        };

        obj.use = function (requires, callback) {
            var module = {
                exports: {}
            };
            var params = obj.buildParams(requires, module);
            var result = callback.apply(this, params);
            if (typeof result != "undefined") {
                return result;
            }
            else {
                return module.exports;
            }
        };

        obj.register = function (name, module) {
            name = obj.processName(name);
            obj.module_objects[name] = module;
        };

        obj.buildParams = function (requires, module) {
            var params = [];
            requires.forEach(function (name) {
                params.push(obj.require(name));
            });
            params.push(obj.require);
            params.push(module.exports);
            params.push(module);
            return params;
        };

        obj.processName = function (name) {
            return name.toLowerCase();
        };

        return {
            define: obj.define,
            use: obj.use,
            register: obj.register,
            modules: obj.module_objects
        };
    })();

    container.define("gm", [], function () {
        var obj = {};

        obj.ready = function (callback) {
            if (typeof GM_getValue != "undefined") {
                callback && callback();
            }
            else {
                setTimeout(function () {
                    obj.ready(callback);
                }, 100);
            }
        };

        return obj;
    });

    container.define("runtime", [], function () {
        var obj = {
            url: location.href
        };

        obj.getUrl = function () {
            return obj.url;
        };

        obj.setUrl = function (url) {
            obj.url = url;
        };

        return obj;
    });

    container.define("object", [], function () {
        var obj = {};

        obj.keys = function (data) {
            var list = [];
            for (var key in data) {
                list.push(key);
            }
            return list;
        };

        obj.values = function (data) {
            var list = [];
            for (var key in data) {
                list.push(data[key]);
            }
            return list;
        };

        return obj;
    });

    container.define("storage", [], function () {
        var obj = {};

        obj.getValue = function (name, defaultValue) {
            return GM_getValue(name, defaultValue);
        };

        obj.setValue = function (name, value) {
            GM_setValue(name, value);
        };

        obj.getValueList = function () {
            var nameList = GM_listValues();
            var valueList = {};
            nameList.forEach(function (name) {
                valueList[name] = obj.getValue(name);
            });
            return valueList;
        };

        return obj;
    });

    container.define("addon", ["storage"], function (storage, constant) {
        var obj = {
            name: constant.name + "_status"
        };

        obj.isEnable = function () {
            if (storage.getValue(obj.name) == "off") {
                return false;
            }
            else {
                return true;
            }
        };

        return obj;
    });

    container.define("config", ["storage", "constant"], function (storage, constant) {
        var obj = {
            name: "config_json"
        };

        obj.getConfig = function (name) {
            var configJson = storage.getValue(obj.name);
            var configObject = obj.parseJson(configJson);
            if (name) {
                name = obj.processName(name);
                return configObject.hasOwnProperty(name) ? configObject[name] : null;
            }
            else {
                return configObject;
            }
        };

        obj.setConfig = function (name, value) {
            var configObject = obj.getConfig();
            configObject[obj.processName(name)] = value;
            storage.setValue(obj.name, JSON.stringify(configObject));
        };

        obj.parseJson = function (jsonStr) {
            var jsonObject = {};
            try {
                if (jsonStr) {
                    jsonObject = JSON.parse(jsonStr);
                }
            }
            catch (e) { }
            return jsonObject;
        };

        obj.processName = function (name) {
            return constant.name + "_" + name;
        };

        return obj;
    });

    container.define("option", ["config", "constant", "object"], function (config, constant, object) {
        var obj = {
            name: "option",
            constant: constant.option
        };

        obj.isOptionActive = function (item) {
            var name = item.name;
            var option = obj.getOption();
            return option.indexOf(name) >= 0 ? true : false;
        };

        obj.setOptionActive = function (item) {
            var name = item.name;
            var option = obj.getOption();
            if (option.indexOf(name) < 0) {
                option.push(name);
                obj.setOption(option);
            }
        };

        obj.setOptionUnActive = function (item) {
            var name = item.name;
            var option = obj.getOption();
            var index = option.indexOf(name);
            if (index >= 0) {
                delete option[index];
                obj.setOption(option);
            }
        };

        obj.getOption = function () {
            var option = [];
            var optionObject = obj.getOptionObject();
            object.values(obj.constant).forEach(function (item) {
                var name = item.name;
                if (optionObject.hasOwnProperty(name)) {
                    if (optionObject[name] != "no") {
                        option.push(name);
                    }
                }
                else if (item.value != "no") {
                    option.push(name);
                }
            });
            return option;
        };

        obj.setOption = function (option) {
            var optionObject = {};
            object.values(obj.constant).forEach(function (item) {
                var name = item.name;
                if (option.indexOf(name) >= 0) {
                    optionObject[name] = "yes";
                } else {
                    optionObject[name] = "no";
                }
            });
            obj.setOptionObject(optionObject);
        };

        obj.getOptionObject = function () {
            var optionObject = config.getConfig(obj.name);
            return optionObject ? optionObject : {};
        };

        obj.setOptionObject = function (optionObject) {
            config.setConfig(obj.name, optionObject);
        };

        return obj;
    });

    container.define("mode", [], function () {
        var obj = {
            constant: {
                addon: "addon",
                script: "script"
            }
        };

        obj.getMode = function () {
            if (typeof GM_info == "undefined") {
                return obj.constant.addon;
            }
            else if (GM_info.scriptHandler) {
                return obj.constant.script;
            }
            else {
                return obj.constant.addon;
            }
        };

        return obj;
    });

    container.define("user", ["storage"], function (storage) {
        var obj = {};

        obj.getUid = function () {
            var uid = storage.getValue("uid");
            if (!uid) {
                uid = obj.randString(32);
                storage.setValue("uid", uid);
            }
            return uid;
        };

        obj.randString = function (length) {
            var possible = "abcdefghijklmnopqrstuvwxyz0123456789";
            var text = "";
            for (var i = 0; i < length; i++) {
                text += possible.charAt(Math.floor(Math.random() * possible.length));
            }
            return text;
        };

        return obj;
    });

    container.define("browser", [], function () {
        var obj = {
            constant: {
                firefox: "firefox",
                edge: "edge",
                baidu: "baidu",
                liebao: "liebao",
                uc: "uc",
                qq: "qq",
                sogou: "sogou",
                opera: "opera",
                maxthon: "maxthon",
                ie2345: "2345",
                se360: "360",
                chrome: "chrome",
                safari: "safari",
                other: "other"
            }
        };

        obj.getBrowser = function () {
            return obj.matchBrowserType(navigator.userAgent);
        };

        obj.matchBrowserType = function (userAgent) {
            var browser = obj.constant.other;
            userAgent = userAgent.toLowerCase();
            if (userAgent.match(/firefox/) != null) {
                browser = obj.constant.firefox;
            } else if (userAgent.match(/edge/) != null) {
                browser = obj.constant.edge;
            } else if (userAgent.match(/bidubrowser/) != null) {
                browser = obj.constant.baidu;
            } else if (userAgent.match(/lbbrowser/) != null) {
                browser = obj.constant.liebao;
            } else if (userAgent.match(/ubrowser/) != null) {
                browser = obj.constant.uc;
            } else if (userAgent.match(/qqbrowse/) != null) {
                browser = obj.constant.qq;
            } else if (userAgent.match(/metasr/) != null) {
                browser = obj.constant.sogou;
            } else if (userAgent.match(/opr/) != null) {
                browser = obj.constant.opera;
            } else if (userAgent.match(/maxthon/) != null) {
                browser = obj.constant.maxthon;
            } else if (userAgent.match(/2345explorer/) != null) {
                browser = obj.constant.ie2345;
            } else if (userAgent.match(/chrome/) != null) {
                if (obj.existMime("type", "application/vnd.chromium.remoting-viewer")) {
                    browser = obj.constant.se360;
                } else {
                    browser = obj.constant.chrome;
                }
            } else if (userAgent.match(/safari/) != null) {
                browser = obj.constant.safari;
            }
            return browser;
        };

        obj.existMime = function (option, value) {
            if (typeof navigator != "undefined") {
                var mimeTypes = navigator.mimeTypes;
                for (var mt in mimeTypes) {
                    if (mimeTypes[mt][option] == value) {
                        return true;
                    }
                }
            }
            return false;
        };

        return obj;
    });

    container.define("env", ["mode", "user", "browser", "constant"], function (mode, user, browser, constant) {
        var obj = {};

        obj.isAddon = function () {
            if (mode.getMode() == mode.constant.addon) {
                return true;
            }
            else {
                return false;
            }
        };

        obj.isInject = function () {
            if (obj.isAddon()) {
                if (GM_info.addon.name != constant.name) {
                    return true;
                }
                else {
                    return false;
                }
            }
            else {
                if (GM_info.script.name && GM_info.script.name != constant.name) {
                    return true;
                }
                else {
                    return false;
                }
            }
        };

        obj.getMode = function () {
            return mode.getMode();
        };

        obj.getAid = function () {
            if (GM_info.addon && GM_info.addon.id) {
                return GM_info.addon.id;
            }
            else if (GM_info.scriptHandler) {
                return GM_info.scriptHandler.toLowerCase();
            }
            else {
                return "unknown";
            }
        };

        obj.getUid = function () {
            return user.getUid();
        };

        obj.getVersion = function () {
            if (obj.isInject()) {
                return injectConfig.version;
            }
            else {
                return GM_info.script.version;
            }
        };

        obj.getBrowser = function () {
            return browser.getBrowser();
        };

        obj.getInfo = function () {
            return {
                mode: obj.getMode(),
                aid: obj.getAid(),
                uid: obj.getUid(),
                version: obj.getVersion(),
                browser: obj.getBrowser()
            };
        };

        return obj;
    });

    container.define("http", [], function () {
        var obj = {};

        obj.ajax = function (option) {
            var details = {
                url: option.url,
                responseType: option.dataType,
                onload: function (result) {
                    option.success && option.success(result.response);
                },
                onerror: function (result) {
                    option.error && option.error(result.error);
                }
            };

            // 提交数据
            if (option.data) {
                details.method = "POST";
                if (option.data instanceof FormData) {
                    details.data = option.data;
                }
                else {
                    var formData = new FormData();
                    for (var i in option.data) {
                        formData.append(i, option.data[i]);
                    }
                    details.data = formData;
                }
            }
            else {
                details.method = "GET";
            }

            // 自定义头
            if (option.headers) {
                details.headers = option.headers;
            }

            // 超时
            if (option.timeout) {
                details.timeout = option.timeout;
            }

            GM_xmlhttpRequest(details);
        };

        return obj;
    });

    container.define("logger", ["env", "constant"], function (env, constant) {
        var obj = {
            level: 3,
            constant: {
                debug: 0,
                info: 1,
                warn: 2,
                error: 3
            }
        };

        obj.debug = function (message) {
            obj.log(message, obj.constant.debug);
        };

        obj.info = function (message) {
            obj.log(message, obj.constant.info);
        };

        obj.warn = function (message) {
            obj.log(message, obj.constant.warn);
        };

        obj.error = function (message) {
            obj.log(message, obj.constant.error);
        };

        obj.log = function (message, level) {
            if (level < obj.level) {
                return false;
            }

            console.group("[" + constant.name + "]" + env.getMode());
            console.log(message);
            console.groupEnd();
        };

        obj.setLevel = function (level) {
            obj.level = level;
        };

        return obj;
    });

    container.define("meta", ["constant", "$"], function (constant, $) {
        var obj = {};

        obj.existMeta = function (name) {
            name = obj.processName(name);
            if ($("meta[name='" + name + "']").length) {
                return true;
            }
            else {
                return false;
            }
        };

        obj.appendMeta = function (name, content) {
            name = obj.processName(name);
            content || (content = "on");
            $('<meta name="' + name + '" content="on">').appendTo($("head"));
        };

        obj.processName = function (name) {
            return constant.name + "::" + name;
        };

        return obj;
    });

    /** custom start **/
    container.define("constant", ["mode", "browser"], function (mode, browser) {
        return {
            name: injectConfig.name,
            mode: mode.constant,
            browser: browser.constant,
            option: {
                site_onlinedown: {
                    name: "site_onlinedown",
                    value: "yes"
                },
                site_cr173: {
                    name: "site_cr173",
                    value: "yes"
                },
                site_xiazaiba: {
                    name: "site_xiazaiba",
                    value: "yes"
                },
                site_mydown: {
                    name: "site_mydown",
                    value: "yes"
                },
                site_pc6: {
                    name: "site_pc6",
                    value: "yes"
                },
                site_zol: {
                    name: "site_zol",
                    value: "yes"
                },
                site_pconline: {
                    name: "site_pconline",
                    value: "yes"
                },
                site_jb51: {
                    name: "site_jb51",
                    value: "yes"
                },
                site_cncrk: {
                    name: "site_cncrk",
                    value: "yes"
                },
                site_pc_qq: {
                    name: "site_pc_qq",
                    value: "yes"
                },
                site_crsky: {
                    name: "site_crsky",
                    value: "yes"
                },
                site_duote: {
                    name: "site_duote",
                    value: "yes"
                },
                site_downza: {
                    name: "site_downza",
                    value: "yes"
                },
                site_yesky: {
                    name: "site_yesky",
                    value: "yes"
                },
                site_ddooo: {
                    name: "site_ddooo",
                    value: "yes"
                },
                site_pchome: {
                    name: "site_pchome",
                    value: "yes"
                },
                site_xpgod: {
                    name: "site_xpgod",
                    value: "yes"
                },
                site_52z: {
                    name: "site_52z",
                    value: "yes"
                },
                site_opdown: {
                    name: "site_opdown",
                    value: "yes"
                }
            }
        };
    });

    container.define("core", [], function () {
        var obj = {};

        obj.ready = function (callback) {
            callback && callback();
        };

        return obj;
    });

    // http://www.onlinedown.net/soft/5.htm
    container.define("app_onlinedown", ["runtime", "option", "$"], function (runtime, option, $) {
        var obj = {};

        obj.run = function () {
            var url = runtime.getUrl();
            if (url.indexOf("onlinedown.net/soft") > 0) {
                option.isOptionActive(option.constant.site_onlinedown) && obj.initDownloadPage();
                return true;
            }
            else {
                return false;
            }
        };

        obj.initDownloadPage = function () {
            // 顶部高速下载
            $(".onedownbtn2").hide();

            // 底部高速下载
            $($(".downDz h4").get(0)).hide();
            $(".downDz .gaosu").hide();

            // 移除弹窗
            $(".wxWp").remove();
        };

        return obj;
    });

    // https://www.cr173.com/soft/18645.html
    container.define("app_cr173", ["runtime", "option", "$"], function (runtime, option, $) {
        var obj = {};

        obj.run = function () {
            var url = runtime.getUrl();
            if (url.indexOf("cr173.com/soft") > 0 || url.indexOf("cr173.com/game") > 0) {
                option.isOptionActive(option.constant.site_cr173) && obj.initSoftPage();
                return true;
            }
            else {
                return false;
            }
        };

        obj.initSoftPage = function () {
            // 顶部高速下载
            $(".downnowgaosu").hide();

            // 底部高速下载
            $(".ul_Address").each(function () {
                if ($(this).find(".f-gsh3").length > 1) {
                    $($(this).find(".f-gsh3").get(0)).hide();
                }
            });
            $(".ul_Address .downurl").hide();
        };

        return obj;
    });

    // https://www.xiazaiba.com/html/82.html
    container.define("app_xiazaiba", ["runtime", "option", "$"], function (runtime, option, $) {
        var obj = {};

        obj.run = function () {
            var url = runtime.getUrl();
            if (url.indexOf("xiazaiba.com/html") > 0) {
                option.isOptionActive(option.constant.site_xiazaiba) && obj.initDownloadPage();
                return true;
            }
            else {
                return false;
            }
        };

        obj.initDownloadPage = function () {
            // 顶部高速下载
            $(".hspeed").hide();

            // 底部高速下载
            $(".needfast").parent().hide();
        };

        return obj;
    });

    // http://www.mydown.com/soft/421/472030921.shtml
    container.define("app_mydown", ["runtime", "option", "$"], function (runtime, option, $) {
        var obj = {};

        obj.run = function () {
            var url = runtime.getUrl();
            if (url.indexOf("mydown.com/soft") > 0) {
                option.isOptionActive(option.constant.site_mydown) && obj.initDownloadPage();
                return true;
            }
            else {
                return false;
            }
        };

        obj.initDownloadPage = function () {
            // 高速下载
            $(".downbtn").hide();
        };

        return obj;
    });

    // http://www.pc6.com/softview/SoftView_1822.html
    // http://www.pc6.com/mod/647389.html
    // http://www.pc6.com/az/254734.html
    container.define("app_pc6", ["runtime", "option", "$"], function (runtime, option, $) {
        var obj = {};

        obj.run = function () {
            var url = runtime.getUrl();
            if (url.indexOf("pc6.com/softview") > 0) {
                option.isOptionActive(option.constant.site_pc6) && obj.initDownloadPageSoft();
                return true;
            }
            else if (url.indexOf("pc6.com/mod") > 0) {
                option.isOptionActive(option.constant.site_pc6) && obj.initDownloadPageSoft();
                return true;
            }
            else if (url.indexOf("pc6.com/az") > 0) {
                option.isOptionActive(option.constant.site_pc6) && obj.initDownloadPageAndroid();
                return true;
            }
            else {
                return false;
            }
        };

        obj.initDownloadPageSoft = function () {
            // 顶部高速下载
            $("#xzbtn .downnow").hide();

            // 底部高速下载
            $(".ul_Address").each(function () {
                if ($(this).find("h3").length > 1) {
                    $($(this).find("h3").get(0)).hide();
                }
            });
            $(".ul_Address #gaosuxiazai").hide();
        };

        obj.initDownloadPageAndroid = function () {
            $(".ul_Address").each(function () {
                if ($(this).find("h3").length > 1) {
                    $($(this).find("h3").get(0)).hide();
                }
            });
            $(".ul_Address #gaosuxiazai").hide();
        };

        return obj;
    });

    // http://xiazai.zol.com.cn/detail/9/89734.shtml
    // http://xiazai.zol.com.cn/index.php?c=Detail_DetailMini&n=e4bd1f21d0c761d05&softid=89734
    container.define("app_zol", ["runtime", "option", "$"], function (runtime, option, $) {
        var obj = {};

        obj.run = function () {
            var url = runtime.getUrl();
            if (url.indexOf("zol.com.cn/detail") > 0) {
                option.isOptionActive(option.constant.site_zol) && obj.initDownloadPage();
                return true;
            }
            else if (url.indexOf("zol.com.cn/index.php") > 0) {
                option.isOptionActive(option.constant.site_zol) && obj.initDownloadPageMini();
                return true;
            }
            else {
                return false;
            }
        };

        obj.initDownloadPage = function () {
            // 顶部高速下载
            $(".soft-text-l").hide();
            $(".soft-text-r").addClass("soft-text-l").removeClass("soft-text-r");

            // 底部高速下载
            $(".box-top-ad").hide();
        };

        obj.initDownloadPageMini = function () {
            $(".down-h4").parent().hide();
            $(".down-jisu").hide();
        };

        return obj;
    });

    // https://dl.pconline.com.cn/download/91034.html
    container.define("app_pconline", ["runtime", "option", "$"], function (runtime, option, $) {
        var obj = {};

        obj.run = function () {
            var url = runtime.getUrl();
            if (url.indexOf("pconline.com.cn/download") > 0) {
                option.isOptionActive(option.constant.site_pconline) && obj.initDownloadPage();
                return true;
            }
            else {
                return false;
            }
        };

        obj.initDownloadPage = function () {
            // 顶部高速下载
            $("#JhsBtn").hide();

            // 底部高速下载
            $($(".links p").get(0)).hide();

            // 误导性广告
            $(".ivy").hide();
        };

        return obj;
    });

    // https://www.jb51.net/softs/40589.html
    // https://www.jb51.net/fonts/658225.html
    // https://www.jb51.net/game/649384.html
    // https://www.jb51.net/codes/575492.html
    container.define("app_jb51", ["runtime", "option", "$"], function (runtime, option, $) {
        var obj = {};

        obj.run = function () {
            var url = runtime.getUrl();
            if (url.indexOf("jb51.net/softs") > 0) {
                option.isOptionActive(option.constant.site_jb51) && obj.initDownloadPage();
                return true;
            }
            else if (url.indexOf("jb51.net/fonts") > 0) {
                option.isOptionActive(option.constant.site_jb51) && obj.initDownloadPage();
                return true;
            }
            else if (url.indexOf("jb51.net/game") > 0) {
                option.isOptionActive(option.constant.site_jb51) && obj.initDownloadPage();
                return true;
            }
            else if (url.indexOf("jb51.net/codes") > 0) {
                option.isOptionActive(option.constant.site_jb51) && obj.initDownloadPage();
                return true;
            }
            else {
                return false;
            }
        };

        obj.initDownloadPage = function () {
            // 顶部高速下载
            $(".gsdw").hide();

            // 底部高速下载
            $($(".address-wrap .gs").get(0)).hide();
            $("#gaosu").hide();
        };

        return obj;
    });

    // http://www.cncrk.com/downinfo/180262.html
    container.define("app_cncrk", ["runtime", "option", "$"], function (runtime, option, $) {
        var obj = {};

        obj.run = function () {
            var url = runtime.getUrl();
            if (url.indexOf("cncrk.com/downinfo") > 0) {
                option.isOptionActive(option.constant.site_cncrk) && obj.initDownloadPage();
                return true;
            }
            else {
                return false;
            }
        };

        obj.initDownloadPage = function () {
            // 高速下载
            $(".downfile_hits").hide();
            $(".download-address").html("<p>全是高(捆)速(绑)下载，已作隐藏处理</p>");
        };

        return obj;
    });

    // https://pc.qq.com/detail/8/detail_11488.html
    container.define("app_qq", ["runtime", "option", "$"], function (runtime, option, $) {
        var obj = {};

        obj.run = function () {
            var url = runtime.getUrl();
            if (url.indexOf("pc.qq.com/detail") > 0) {
                option.isOptionActive(option.constant.site_pc_qq) && obj.initDownloadPage();
                return true;
            }
            else {
                return false;
            }
        };

        obj.initDownloadPage = function () {
            // 高速下载
            $(".detail-install-fast").hide();
        };

        return obj;
    });

    // https://www.crsky.com/soft/48442.html
    container.define("app_crsky", ["runtime", "option", "$"], function (runtime, option, $) {
        var obj = {};

        obj.run = function () {
            var url = runtime.getUrl();
            if (url.indexOf("crsky.com/soft") > 0) {
                option.isOptionActive(option.constant.site_crsky) && obj.initDownloadPage();
                return true;
            }
            else {
                return false;
            }
        };

        obj.initDownloadPage = function () {
            $($(".i_dwon a").get(1)).hide();

            $(".Adown_dli").hide();
        };

        return obj;
    });

    // http://www.duote.com/soft/314065.html
    container.define("app_duote", ["runtime", "option", "$"], function (runtime, option, $) {
        var obj = {};

        obj.run = function () {
            var url = runtime.getUrl();
            if (url.indexOf("duote.com/soft") > 0) {
                option.isOptionActive(option.constant.site_duote) && obj.initDownloadPage();
                return true;
            }
            else {
                return false;
            }
        };

        obj.initDownloadPage = function () {
            // 误导广告
            $(".dl-banner").hide();

            // 底部高速下载
            $(".down-lists").each(function () {
                if ($(this).find(".download-box").length > 1) {
                    $($(this).find(".download-box").get(0)).hide();
                }
            });
        };

        return obj;
    });

    // http://www.downza.cn/soft/193456.html
    container.define("app_downza", ["runtime", "option", "$"], function (runtime, option, $) {
        var obj = {};

        obj.run = function () {
            var url = runtime.getUrl();
            if (url.indexOf("downza.cn/soft") > 0 || url.indexOf("downza.cn/android") > 0) {
                option.isOptionActive(option.constant.site_downza) && obj.initDownloadPage();
                return true;
            }
            else {
                return false;
            }
        };

        obj.initDownloadPage = function () {
            // 顶部高速下载
            $("#xzqIMG1").hide();

            // 底部高速下载
            $($(".pc-down_url_left .pull-left div").get(0)).hide();
            $(".pc-down_url_left .down_top").hide();
        };

        return obj;
    });

    // http://mydown.yesky.com/pcsoft/266126.html
    container.define("app_yesky", ["runtime", "option", "$"], function (runtime, option, $) {
        var obj = {};

        obj.run = function () {
            var url = runtime.getUrl();
            if (url.indexOf("yesky.com/pcsoft") > 0) {
                option.isOptionActive(option.constant.site_yesky) && obj.initDownloadPage();
                return true;
            }
            else if (url.indexOf("yesky.com/game") > 0) {
                option.isOptionActive(option.constant.site_yesky) && obj.initDownloadPage();
                return true;
            }
            else {
                return false;
            }
        };

        obj.initDownloadPage = function () {
            // 顶部高速下载
            $(".bkdown").hide();
            $("#local_down").show();

            // 底部高速下载
            $($(".bk-soft_downurl .url h4").get(0)).hide();
            $(".bk-soft_downurl .down_referer").hide();
            $(".bk-soft_downurl hr").hide();
        };

        return obj;
    });

    // http://www.ddooo.com/softdown/65448.htm
    container.define("app_ddooo", ["runtime", "option", "$"], function (runtime, option, $) {
        var obj = {};

        obj.run = function () {
            var url = runtime.getUrl();
            if (url.indexOf("ddooo.com/softdown") > 0) {
                option.isOptionActive(option.constant.site_ddooo) && obj.initDownloadPage();
                return true;
            }
            else {
                return false;
            }
        };

        obj.initDownloadPage = function () {
            // 顶部高速下载
            $(".gsbtn1").hide();

            // 底部高速下载
            $($(".txtfont").get(0)).hide();
            $(".c_down").hide();
        };

        return obj;
    });

    // https://download.pchome.net/mobile/games/other/download-193583.html
    container.define("app_pchome", ["runtime", "option", "$"], function (runtime, option, $) {
        var obj = {};

        obj.run = function () {
            var url = runtime.getUrl();
            if (url.indexOf("download.pchome.net") > 0 && url.indexOf("/download-") > 0) {
                option.isOptionActive(option.constant.site_pchome) && obj.initDownloadPage();
                return true;
            }
            else {
                return false;
            }
        };

        obj.initDownloadPage = function () {
            // 不需提示
            $(".dl-tip").hide();

            // 混淆广告
            $(".mod_banner").hide();
        };

        return obj;
    });

    // https://www.xpgod.com/soft/121.html
    container.define("app_xpgod", ["runtime", "option", "$"], function (runtime, option, $) {
        var obj = {};

        obj.run = function () {
            var url = runtime.getUrl();
            if (url.indexOf("xpgod.com/soft") > 0) {
                option.isOptionActive(option.constant.site_xpgod) && obj.initDownloadPage();
                return true;
            }
            else {
                return false;
            }
        };

        obj.initDownloadPage = function () {
            // 顶部高速下载
            $($("#bzxz a").get(1)).hide();

            // 底部高速下载
            $(".show_xzq").hide();
        };

        return obj;
    });

    // https://www.52z.com/soft/389669.html
    container.define("app_52z", ["runtime", "option", "$"], function (runtime, option, $) {
        var obj = {};

        obj.run = function () {
            var url = runtime.getUrl();
            if (url.indexOf("52z.com/soft") > 0) {
                option.isOptionActive(option.constant.site_52z) && obj.initDownloadPage();
                return true;
            }
            else {
                return false;
            }
        };

        obj.initDownloadPage = function () {
            // 高速下载
            setTimeout(function () {
                $($(".elYxxzIn").get(0)).hide();
            }, 1000);
        };

        return obj;
    });

    // http://www.opdown.com/soft/23485.html
    container.define("app_opdown", ["runtime", "option", "$"], function (runtime, option, $) {
        var obj = {};

        obj.run = function () {
            var url = runtime.getUrl();
            if (url.indexOf("opdown.com/soft") > 0) {
                option.isOptionActive(option.constant.site_opdown) && obj.initDownloadPage();
                return true;
            }
            else {
                return false;
            }
        };

        obj.initDownloadPage = function () {
            // 高速下载
            $(".downnows").hide();
            $(".listaddr").hide();
        };

        return obj;
    });

    container.define("app_newday", ["env", "config", "option", "meta", "vue"], function (env, config, option, meta, vue) {
        var obj = {};

        obj.run = function () {
            if (meta.existMeta("option")) {
                obj.initOptionPage();
                return true;
            }
            else {
                return false;
            }
        };

        obj.initOptionPage = function () {
            new vue({
                el: "#container",
                data: {
                    info: env.getInfo(),
                    option: option.getOption(),
                    check_switch: config.getConfig("check_switch") == "off" ? false : true
                },
                created: function () {
                    obj.initAddonReady();
                },
                watch: {
                    option: function (value) {
                        option.setOption(value);
                    },
                    check_switch: function (value) {
                        config.setConfig("check_switch", value ? "on" : "off");
                    }
                }
            });
        };

        obj.initAddonReady = function () {
            $("body").addClass("nd-addon-ready");
        };

        return obj;
    });

    container.define("app", ["runtime", "addon", "config", "logger", "meta", "$"], function (runtime, addon, config, logger, meta, $, require) {
        var obj = {
            check_switch: "check_switch"
        };

        obj.run = function () {
            var metaName = "status";
            if (meta.existMeta(metaName)) {
                logger.warn("setup already");
            }
            else if (addon.isEnable()) {
                logger.info("setup success");

                // 添加meta
                meta.appendMeta(metaName);

                // 运行应用
                $(obj.runApp);
            }
            else {
                logger.warn("addon disabled");
            }
        };

        obj.getAppList = function () {
            return [
                {
                    name: "app_onlinedown",
                    matchs: [
                        "onlinedown.net"
                    ],
                    switch: obj.check_switch
                },
                {
                    name: "app_cr173",
                    matchs: [
                        "cr173.com"
                    ],
                    switch: obj.check_switch
                },
                {
                    name: "app_xiazaiba",
                    matchs: [
                        "xiazaiba.com"
                    ],
                    switch: obj.check_switch
                },
                {
                    name: "app_mydown",
                    matchs: [
                        "mydown.com"
                    ],
                    switch: obj.check_switch
                },
                {
                    name: "app_pc6",
                    matchs: [
                        "pc6.com"
                    ],
                    switch: obj.check_switch
                },
                {
                    name: "app_zol",
                    matchs: [
                        "zol.com.cn"
                    ],
                    switch: obj.check_switch
                },
                {
                    name: "app_pconline",
                    matchs: [
                        "pconline.com.cn"
                    ],
                    switch: obj.check_switch
                },
                {
                    name: "app_jb51",
                    matchs: [
                        "jb51.net"
                    ],
                    switch: obj.check_switch
                },
                {
                    name: "app_cncrk",
                    matchs: [
                        "cncrk.com"
                    ],
                    switch: obj.check_switch
                },
                {
                    name: "app_qq",
                    matchs: [
                        "pc.qq.com"
                    ],
                    switch: obj.check_switch
                },
                {
                    name: "app_crsky",
                    matchs: [
                        "www.crsky.com"
                    ],
                    switch: obj.check_switch
                },
                {
                    name: "app_duote",
                    matchs: [
                        "duote.com"
                    ],
                    switch: obj.check_switch
                },
                {
                    name: "app_downza",
                    matchs: [
                        "downza.cn"
                    ],
                    switch: obj.check_switch
                },
                {
                    name: "app_yesky",
                    matchs: [
                        "yesky.com"
                    ],
                    switch: obj.check_switch
                },
                {
                    name: "app_ddooo",
                    matchs: [
                        "ddooo.com"
                    ],
                    switch: obj.check_switch
                },
                {
                    name: "app_pchome",
                    matchs: [
                        "pchome.net"
                    ],
                    switch: obj.check_switch
                },
                {
                    name: "app_xpgod",
                    matchs: [
                        "xpgod.com"
                    ],
                    switch: obj.check_switch
                },
                {
                    name: "app_52z",
                    matchs: [
                        "52z.com"
                    ],
                    switch: obj.check_switch
                },
                {
                    name: "app_opdown",
                    matchs: [
                        "opdown.com"
                    ],
                    switch: obj.check_switch
                },
                {
                    name: "app_newday",
                    matchs: [
                        "*"
                    ]
                }
            ];
        };

        obj.runApp = function () {
            var url = runtime.getUrl();
            logger.info(url);

            var appList = obj.getAppList();
            for (var i in appList) {
                var app = appList[i];
                logger.debug(app);

                var match = obj.matchApp(url, app);
                logger.debug("match " + (match ? "yes" : "no"));

                if (match == false) {
                    continue;
                }

                if (app.switch && config.getConfig(app.switch) == "off") {
                    continue;
                }

                logger.info("run " + app.name);
                if (require(app.name).run() == true) {
                    break;
                }
            }
        };

        obj.matchApp = function (url, app) {
            var match = false;
            app.matchs.forEach(function (item) {
                if (url.indexOf(item) > 0 || item == "*") {
                    match = true;
                }
            });
            return match;
        };

        return obj;
    });

    // 注册模块
    container.define("$", [], function () {
        return window.$;
    });
    container.define("vue", [], function () {
        return window.Vue;
    });

    container.use(["gm", "core", "app", "logger"], function (gm, core, app, logger) {
        gm.ready(function () {
            // 日志级别
            logger.setLevel(logger.constant.info);

            core.ready(app.run);
        });
    });

})();