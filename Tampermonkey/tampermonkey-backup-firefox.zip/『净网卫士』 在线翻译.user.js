// ==UserScript==
// @author            Hunlongyu
// @name              『净网卫士』 在线翻译
// @namespace         https://github.com/Hunlongyu
// @icon              https://i.loli.net/2019/04/22/5cbd720718fdb.png
// @description       精简页面，移除广告，优化布局。适配：百度翻译、谷歌翻译、有道翻译、金山词霸、必应翻译、搜狗翻译。
// @version           0.1.0
// @include           *://fanyi.baidu.com/*
// @include           *://www.iciba.com/*
// @include           *://translate.google.cn/*
// @include           *://fanyi.youdao.com/*
// @include           *://cn.bing.com/translator/*
// @include           *://fanyi.sogou.com/*
// @grant             GM_addStyle
// @run-at            document-start
// @supportURL        https://gist.github.com/Hunlongyu/fbd80bac47b8a2aba216fe5c3399b464
// ==/UserScript==

(function () {
  'use strict'

  const website = [
    {
        name: 'baidu',
        css: `
            .header, .footer, .trans-other-right, .manual-trans-btn{display: none !important;}
        `
    },
    {
        name: 'iciba',
        css: `
            .nav, .home-download, .home-func, .home-pc, .footer, .cb-downmask, .ad-left, .search-ad, .base-bt-bar{display: none !important;}
            html{background-color: #3988e5;}
            .home-banner{background-image: none !important;background-color: #3988e5;}
            .common-top, .container-right, .info-product, .info-hotwords, .goto-top-2, .foot-top-seo,.ad-left2, .foot{display: none !important;}
        `
    },
    {
        name: 'google',
        css: `
            .app-download-bar, #gb{display: none !important;}
        `
    },
    {
        name: 'youdao',
        css: `
            .fanyi__nav, .inside__products, .fanyi__footer, .side__nav, #transMan{display: none !important;}
            .fanyi{padding-top: 20px;}
        `
    },
    {
        name: 'bing',
        css: `
            .t_header, .t_navigation, .b_footer{display: none !important;}
            #tt_translatorHome{width: 96% !important;}
        `
    },
    {
        name: 'sogou',
        css: `
            .header, .logo-translation, .trans-footer, .header-fanyi, #J_download_app, .trans-tab{display: none !important;}
            body{ min-height: inherit !important;}
        `
    }
  ]

  let url = window.location.href
  for (let i = 0; i < website.length; i++) {
    if (url.indexOf(website[i].name) !== -1) {
        return GM_addStyle(website[i].css)
    }
  }
})()