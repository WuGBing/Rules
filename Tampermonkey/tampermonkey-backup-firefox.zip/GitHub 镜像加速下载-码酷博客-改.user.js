// ==UserScript==
// @icon            https://github.githubassets.com/favicon.ico
// @name            GitHub 镜像加速下载-码酷博客-改
// @namespace       https://github.com/FireSoil
// @author          wzz
// @description     加速GitHub克隆和下载
// @match           *://github.com/*
// @require         http://cdn.bootcss.com/jquery/1.8.3/jquery.min.js
// @version         1.0.4
// @grant           GM_addStyle
// ==/UserScript==

(function () {
 'use strict';
 var yuan =  window.location.href+'.git';
 var mirror_url1 = 'i.codeku.me';
 var mirror_url2 = 'v2.github.codeku.me';
 var a = yuan.split("/");
 var str1 = 'http://'+ mirror_url1 + '/'+a[3]+'/'+a[4];
 var str3 = 'http://'+ mirror_url2 + '/'+a[3]+'/'+a[4];
 var qc = a[4].split(".")
 var str2 = 'http://'+'ws.codeku.me/'+a[3]+'/'+qc[0]+'/zip/master';
  //$('.mt-2').append('快速克隆通道:<input value="'+str1+'">')

 var info = `
    <details class="ment">
      <summary><b>这是一条国内快速通道(点击显示)</b></summary>
      <div style="height:100px;border:2px dashed ;">
       <center>
       <div>快速克隆通道A1：<input style="width:300px;height:30px" value="${str1}"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;快速下载通道：<a href="${str2}" id="down">点我下载</div></a>
      快速克隆通道A2：<input style="width:300px;height:30px" value="${str3}"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;快速下载通道：<a href="${str2}" id="down">点我下载</div></a></div>
       </div>
      </center>
    </div>
</details>
</br>
 `;
 
  $('.repository-content').prepend(info);
  $('.release-entry').each(function(){
      $(this).find('.Box-body>a').each(function(){
          var href = $(this).attr('href');
          var url1 = 'http://'+mirror_url1+href;
          var url2 = 'http://'+mirror_url2+href;
          var span1 = `&nbsp;<a href="${url1}"><span class="text-bold">快速下载通道1</span></a>`;
          var span2 = `&nbsp;<a href="${url2}"><span class="text-bold">快速下载通道2</span></a>`;

          $(this).after(span2);
          $(this).after(span1);
      });
  });
})();
