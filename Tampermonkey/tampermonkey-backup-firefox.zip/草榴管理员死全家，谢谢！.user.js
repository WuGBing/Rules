// ==UserScript==
// @name          草榴管理员死全家，谢谢！
// @namespace     http://userstyles.org
// @description	  1024去广告
// @author        pekinghot
// @version       191203
// @homepage      https://bbs.kafan.cn/thread-2115085-1-1.html
// @include       http://cl.dzcl.pw/*
// @include       https://cl.dzcl.pw/*
// @include       http://*.cl.dzcl.pw/*
// @include       https://*.cl.dzcl.pw/*
// @include       http://woyao.cl/*
// @include       https://woyao.cl/*
// @include       http://*.woyao.cl/*
// @include       https://*.woyao.cl/*
// @include       http://cl.nea.cl/*
// @include       https://cl.nea.cl/*
// @include       http://*.cl.nea.cl/*
// @include       https://*.cl.nea.cl/*
// @include       http://cl.patf.com/*
// @include       https://cl.patf.com/*
// @include       http://*.cl.patf.com/*
// @include       https://*.cl.patf.com/*
// @include       http://cl.arlew.com/*
// @include       https://cl.arlew.com/*
// @include       http://*.cl.arlew.com/*
// @include       https://*.cl.arlew.com/*
// @include       http://t66y.com/*
// @include       https://t66y.com/*
// @include       http://*.t66y.com/*
// @include       https://*.t66y.com/*
// @include       http://184.154.128.243/*
// @include       https://184.154.128.243/*
// @include       http://*.184.154.128.243/*
// @include       https://*.184.154.128.243/*
// @include       http://cl.s1.lv/*
// @include       https://cl.s1.lv/*
// @include       http://*.cl.s1.lv/*
// @include       https://*.cl.s1.lv/*
// @include       http://wo.yao.cl/*
// @include       https://wo.yao.cl/*
// @include       http://*.wo.yao.cl/*
// @include       https://*.wo.yao.cl/*
// @include       http://c1521.biz.tm/*
// @include       https://c1521.biz.tm/*
// @include       http://*.c1521.biz.tm/*
// @include       https://*.c1521.biz.tm/*
// @include       http://cl.cyline.org/*
// @include       https://cl.cyline.org/*
// @include       http://*.cl.cyline.org/*
// @include       https://*.cl.cyline.org/*
// @include       http://chenli1027.gicp.net/*
// @include       https://chenli1027.gicp.net/*
// @include       http://*.chenli1027.gicp.net/*
// @include       https://*.chenli1027.gicp.net/*
// @run-at        document-start
// ==/UserScript==
(function() {var css = [
	"@namespace url(http://www.w3.org/1999/xhtml);",
    ".quote,blockquote,img[src*=\"sc02.alicdn.com\"],img[src*=\"e.piclect.com\"],img[src*=\"kk.51688.cc\"],img[src*=\"www.yuoimg.com\"],img[src*=\"www.x6img.com\"],img[src*=\"www.touimg.com\"],img[src*=\"dioimg.net\"],div.t.t2 div.tpc_content>br + br,.sptable_do_not_remove,a+a+iframe,#iframe1,#iframe2,#iframe3,#iframe4,#iframe5,div.tpc_content a[href$=\"html&z\"],div.tpc_content a[href$=\"htm&z\"],div.tpc_content a[href$=\"com&z\"],div.tpc_content a[href$=\"net&z\"],div.tpc_content a[href*=\"/?Intr=\"],div.tpc_content a[href*=\"/?Agent=\"],div.tpc_content a[href*=\"/&z\"],div.tpc_content a[href*=\"vip&z\"],div.tpc_content a[href*=\"/?a=\"],div.tpc_content a[href*=\"/?p=\"],div.tpc_content a[href*=\"/?aff=\"],div.tpc_content a[onclick*=\"getElementById\"],a[style*=\"47, 95, 161\"],div.t.t2 div.tpc_content>b{display: none !important;}",
	"div[class=\"tips\"],a + a + iframe{height: 2px !important;padding: 0px !important}"
].join("\n");
if (typeof GM_addStyle != "undefined") {
	GM_addStyle(css);
} else if (typeof PRO_addStyle != "undefined") {
	PRO_addStyle(css);
} else if (typeof addStyle != "undefined") {
	addStyle(css);
} else {
	var node = document.createElement("style");
	node.type = "text/css";
	node.appendChild(document.createTextNode(css));
	var heads = document.getElementsByTagName("head");
	if (heads.length > 0) {
		heads[0].appendChild(node);
	} else {
		// no head yet, stick it whereever
		document.documentElement.appendChild(node);
	}
}
})();
