// ==UserScript==
// @author            Hunlongyu
// @name              『净网卫士』 下载网站
// @namespace         https://github.com/Hunlongyu
// @icon              https://i.loli.net/2019/04/22/5cbd720718fdb.png
// @description       移除下载网站的广告、推荐、高速下载等，尽可能多的移除干扰项。
// @version           0.0.5
// @include           *://*.cr173.com/*
// @include           *://*.onlinedown.*/*
// @include           *://*.xiazaiba.*/*
// @include           *://*.mydown.*/*
// @include           *://*.pc6.*/*
// @include           *://xiazai.zol.com.cn/*
// @include           *://dl.pconline.com.cn/*
// @include           *://*.cncrk.com/*
// @include           *://pc.qq.com/*
// @include           *://*.crsky.com/*
// @include           *://*.duote.com/*
// @include           *://*.ddooo.com/*
// @include           *://*.xpgod.com/*
// @grant             GM_addStyle
// @run-at            document-start
// ==/UserScript==

(function () {
  'use strict'

  // 西西软件园 https://www.cr173.com/
  const cr173 = `
    .c_soft_pic, .m-soft-ad, .c_soft_same, .m-soft-relat, .downnowgaosu, #good_or_bad, .share_box, .m-key-link, .m-dir-imgbg, .g-downxg, .g-downaddli, .g-add-version,
    .inswtable, #xiangua, #g-skill, #full_downad, .f-gsh3, .downurl, #class-soft, #class-cms, #other, #comment_list, #downhelp, .c_info_side{display: none !important}
    .c_soft_button{height: 0px; border: none;}
    .c_info_content, .c_des_content, #download{width: 1240px;}
    #content{padding-right: 30px;}
  `
  // 华军软件园 http://www.onlinedown.net/
  const onlinedown = `
    .mc, .fbBtn, .relateSoft, .gg300, .softDownIf>.right, .meg, .xianssort, .xgshach, #ItemXGJC, #ItemSSZT, #ItemXGZT, #ItemXGXZ, .XZDZitem>.ad, .downgs, .downDz>h4,
    #ItemWYPL, #ItemCNXH, .Friendlink, .greatrec, .wxWp, .qitaRankLast, .right .ad{display: none !important}
    .onedownbtn2{visibility: hidden !important}
    .softDownIf>.left{width: 100%;}
    .downlist a{color: #018ee1;}
  `

  // 下载吧 https://www.xiazaiba.com/
  const xiazaiba = `
    .search-adv, .adv-90, .hspeed, .ess-title, .soft-interest, .needfast, .gdown-btns, #downlist .sdown-item:nth-child(1), #downlist .sdown-item:nth-child(3), .detail-inter{display: none !important}
  `

  // 极速下载 http://www.mydown.com/
  const mydown = `
    .gotop2, .con_right .box, .guangr1, .guangr2, .guangr3, .downbtn, #softlsbxz, .hji_con, .comlist, .dbtntg{display: none !important}
    .otherloadurl{margin-top: 10px;}
  `

  // pc6下载站 http://www.pc6.com/
  const pc6 = `
    #bdfx, #fbrj, .downnow, #param-box .ad, .tagsk, #xgk, .ad-download, #gaosuxiazai, .ul_Address h3:nth-child(2), #reci, #necessary, #samesoft, #xgd, #xgw{display: none !important}
  `

  // ZOL软件下载 http://xiazai.zol.com.cn
  const zol = `
    .soft-text-l #downloader_main, .soft-bottom, .soft-summary-mt>div:nth-child(2), .ad-div, .recommend-soft-box, .down-right, .down-left .box-top-ad, #discussArea, .send-post, .tonglan-foot,
    .pic-list-r, .lastest-comments-section, .hot-soft-list{display: none !important}
    .detailSoft-box .soft-box {min-height: 200px;}
  `

  // 太平洋电脑网下载中心 https://dl.pconline.com.cn/
  const pconline = `
    .ivy, .publish-area, #JhsBtn, .otherVersions, .nav-wrap-r, .pc-share, #rela-subject, .rela-new, .rela-cmt, .rela-best, .box-push, .sc-last, .navi-bottom{display: none !important}
  `

  // 起点软件园 http://www.cncrk.com/
  const cncrk = `
    #gsxza, #container, .area-c, #jprj, .xzbox-lf, .gsdt, #djdxh{display: none !important}
  `

  // 腾讯软件中心
  const qq = `
    .detail-install-fast, .detail-recomm, .comment-box, .banmgr-box, .tbr-bigbox{display: none !important}
  `

  // 非凡软件站 https://www.crsky.com/
  const crsky = `
    .Gs_d, .Intab, .Adown_dli, .boxauto{display: none !important}
    .Amain_topleft{visibility: hidden;}
  `

  // 多特软件站 http://www.duote.com/
  const duote = `
    #hengfu, .msgbox-wrap, .mask, .pic-bannerA, .links-banner, #middle_banner, .bd>div:nth-child(3), .bd>div:nth-child(4), .down-ad, #pic_container,
    .ad, #u3449697{display: none !important}
    .download-resource{height: auto;}
  `

  // 多多软件站 http://www.ddooo.com/
  const ddooo = `
    .gsbtn1, .ads, .txtfont, .c_down{display: none !important}
  `

  // 系统天堂 http://www.xpgod.com/
  const xpgod = `
    .art_lm_gg, #bzxz>a:nth-child(2), .tltj_r, .soft_rmsy, .rmzt, .show_xzq, .down_r, #cnxh, .gg, .soft_snap{display: none !important}
  `

  let url = window.location.href
  const urlArr = [cr173, onlinedown, xiazaiba, mydown, pc6, zol, pconline, cncrk, qq, crsky, duote, ddooo, xpgod]
  const strArr = ['cr173', 'onlinedown', 'xiazaiba', 'mydown', 'pc6', 'zol', 'pconline', 'cncrk', 'qq', 'crsky', 'duote', 'ddooo', 'xpgod']

  for (let i = 0; i < urlArr.length; i++) {
    if (url.indexOf(strArr[i]) !== -1) {
      return GM_addStyle(urlArr[i])
    }
  }
})()
