// ==UserScript==
// @name         破解微信编辑器会员限制
// @namespace    https://ziyuand.cn/
// @version      0.2
// @description  简单去除135编辑器、96编辑器、主编编辑器vip限制
// @author       Sherwin
// @match        https://www.135editor.com/*
// @match        http://www.zhubian.com/*
// @match        http://bj.96weixin.com
// @grant        none
//@require http://cdn.bootcss.com/jquery.min.js
// ==/UserScript==

(function() {

  $(".g-view-mask").remove();
  $('div').click(function(e){
      $(".modal-backdrop.show").remove();
      $(".style-item.vip-style").removeClass("vip-style").addClass("style-item");
      $("._135editor").attr("data-tools","Sherwin破解");
      $(".rich_media_content").attr("data-vip","1");
  });

    $(".modal.show").remove();
    $(".modal-backdrop.show").remove();

})();