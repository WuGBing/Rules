// ==UserScript==
// @name Image Search Exclusion
// @namespace Violentmonkey Scripts
// @description Blacks out images not supported by Image Max URL
// @match *://image.baidu.com/*
// @include /^https?:\/\/[^/]*google\.[a-z]+\/.*tbm=isch/
// @include /^https?:\/\/[^/]*images\.search\.yahoo\.[a-z]+\//
// @include /^https?:\/\/[^/]*bing\.[a-z]+\/images\/search/
// @include /^https?:\/\/[^/]*duckduckgo\.com\/.*?&ia=images/
// @include /^https?:\/\/[^/]*startpage\.com\/do\/a?search/
// @include /^https?:\/\/[^/]*tineye\.com\/search\/[0-9a-f]+\//
// @include /^https?:\/\/[^/]*yandex\.ru\/images\/search/
// @include /^https?:\/\/[^/]*qwant\.com\/\?(?:.*&)?t=images/
// @include /^https?:\/\/[^/]*dogpile\.com\/serp\?(?:.*&)?qc=images/
// @include /^https?:\/\/[^/]*gigablast\.com\/search\?(?:.*&)?searchtype=images/
// @//include /^https?:\/\/[^/]*metager\.org\/meta\/+meta\.ger3\?(?:.*&)?focus=bilder/ -- doesn't work, because it only lists the bing image
// @include /^https?:\/\/[^/]*ecosia\.org\/images\?/
// @include /^https?:\/\/[^/]*searchencrypt\.com\/images\?/
// @match *://searx.me/*
// @grant GM_xmlhttpRequest
// @run-at document-end
// @version 0.2.3
// ==/UserScript==

(function() {
    var console_log = console.log;

    var selectors = [
        // baidu
        {
            parent: ".imgitem",
            link: ".imgbox > a"
        },
        // google
        {
            //parent: "#ires > div > div > div > div > div > div",
            parent: "#search > div > #rso > div > div > #rg > div > div.rg_el",
            link: "a",
            preprocess: function(div) {
                div.style.height = "initial";
                var alist = div.querySelectorAll("a");
                if (alist.length === 2)
                    alist[0].style.height = "initial"
                /*div.style.height = "intial";
                div.querySelector("a").style.height = "intial";
                div.querySelector("a > img").style.height = "initial";*/
            }
        },
        // yahoo
        {
            parent: "#results > div > ul > li",
            link: "a"
        },
        // bing
        {
            parent: "#mmComponent_images_1 > ul > li",
            link: "div > div > a"
        },
        // bing reverse image search
        {
            parent: "#i_results #vs_images .expander_content > ul > li > div",
            link: "a.richImgLnk"
        },
        // startpage
        {
            parent: ".img-wrapper > article.columns > #image-results > li.image-result",
            link: ".image-result__overlay > a",
            image: ".image-result__image > img"
        },
        // searx
        {
            parent: "#main_results > div.result.result-images",
            link: "a[rel='noreferrer']"
        },
        // tineye
        {
            parent: ".results > .matches > .match-row",
            link: ".match-details .match .image-link a"
        },
        // yandex
        {
            parent: "div.serp-controller__content > div.serp-list.serp-list_type_search > div.serp-item.serp-item_type_search",
            link: ".serp-item__preview > .serp-item__link"
        },
        // qwant
        {
            parent: "#images__fragment--container .result_fragment > .result--images",
            link: "a.result__link"
        },
        // dogpile
        {
            parent: ".images-bing__list > .image",
            link: "a.link"
        },
        // gigablast
        {
            parent: "#maincol #box > table table.result",
            link: "table.image a"
        },
        // metager
        {
            parent: "#results-container .image-container > .image",
            link: "div > img"
        },
        // ecosia
        {
            parent: ".image-results .image-result",
            link: ""
        },
        // searchencrypt
        {
            parent: "#search-app #images > .item",
            link: "img"
        }
    ];
    
    var defaults = [
        "",
        "/wp-content/uploads/",
        "\\.files\\.wordpress\\.com",
        "/sites/[^/]*/files/",
        "$i.dailymail.co.uk",
        "$img.dailymail.co.uk",
        "$[^/]*gettyimages\\.com/",
        "$\\.alamy\\.com/",
        "$pinimg\\.",
        "$pbs\\.twimg\\.",
        "$sinaimg\\.",
        "$\\.fbsbx\\.",
        "$\\.cdninstagram\\.",
        "$instagram\\.[^/]*\\.fbcdn\\.net/",
        "$\\.hdslb\\.",
        "$\\.ytimg\\.",
        "$ytimg\\.googleusercontent\\.com/",
        "$img\\.youtube\\.com/",
        "$i\\.imgur\\.com/",
        "$imgur\\.com/",
        "$\\.127\\.net",
        "$\\.static\\.?flickr\\.",
        "$\\.tumblr\\..*_1280\\.[^/]*$",
        "$\\.upaiyun\\.",
        "$\\.meitudata\\.",
        "$wikia\\.nocookie\\.net",
        "$\\.inven\\.co\\.kr",
        "$\\.fastly\\.net/",
        "$\\.wikifeet\\.com/",
        "$\\.famousbirthdays\\.com",
        "$\\.eonline\\.com/",
        "$\\.depositphotos\\.com/",
        "$\\.stylebistro\\.com/",
        "$\\.zimbio\\.com/",
        "$images\\.hellogiggles\\.com/",
        "$\\.deviantart\\.net/",
        "$\\.shutterstock\\.com/",
        "$\\.dreamstime\\.com/",
        "$\\.bigstockphoto\\.com/",
        "$data\\.whicdn\\.com/",
        "$contactmusic\\.com/",
        "$123rf\\.com/",
        "$\\.joins\\.com/",
        "$\\.topstarnews\\.net/",
        "$\\.chosun\\.com/",
        "$img\\.discogs\\.com/", // haven't found a pattern yet
        "$\\.imgix\\.net/",
        "$\\.narvii\\.com/",
        "$(?:cdn|s[0-9]*)\\.namuwikiusercontent\\.com",
        "$w\\.namu\\.la/",
        // https://ncache.ilbe.com/files/attach/new/20121227/14357299/446289814/563253625/36914192240a5b2a2aa3ca1fce5a60e3.jpg
        // https://www.neoanime.co.kr/files/attach/images/111/038/053/008/c676ce5a8eea1875021f0fad1d7837bb.jpg
        // https://lovelive.kr/xe/files/attach/images/525/773/382/b0a5392fae73ad73d30b72fa90918d24.jpg
        // http://www.onlifezone.com/files/thumbnails/981/341/014/210x130.crop.jpg
        // http://romeo1052.net/xe/files/thumbnails/293/127/220x200.ratio.jpg?20161111100505
        // http://missdica.com/files/cache/thumbnails/936/549/002/180x180.crop.jpg
        "://[^/]*/+(?:xe\/+)?files/+(?:cache\/+)?(?:attach/(?:images|new)|thumbnails)/+[0-9]+/+[0-9]+/", // common pattern in korean websites (xe?)
        "$\\.weebly\\.com/",
        "$contents\\.oricon\\.co\\.jp/",
        "$\\.(?:ssl-)?(?:images|media)-(?:amazon|imdb)\\.com/",
        "$\\.blogimg\\.jp",
        "$\\.fc2\\.com",
        "$\\.wikimedia\\.org/",
        "$image\\.dhgate\\.com/",
        "$dhresource\\.com/",
        "$postimg\\.cc\/",
        "$i\\.redditmedia\\.com/",
        "$\\.alicdn\\.com/",
        "$\\.kym-cdn\\.com/",
        "://[^/]*\/data\/out\/[0-9]+\/[0-9]+-[^/]*$",
        "$i[0-9]*\\.kknews\\.cc/SIG=",
        "$\\.read01\\.com/SIG=",
        "://[^/]*/thumbnail/[0-9]+/gallery/[^/]*$",
        "$tse?[0-9]*\\.mm\\.bing\\.net/",
        "$partners-programs.ru/thumbs/",
        "$i.redd.it/",
        "$.ask.fm/.*/original/",
        "$kn3.net/taringa/",
        "$snap69.com/thumb\.php",
        "$pp.userapi.com/",
        "$thumbnails[0-9]*\\.imagebam\.com/",
        "$x\\.imagefapusercontent\\.com/",
        "$\\.fansshare\\.com/",
        "$i[0-9]*\\.photobucket\\.com/",
        "$\\.wattpad\\.com/",
        "^x-raw-image:\/\/",
        "$archive\\.is/",
        "$i\\.ntere\\.st/",
        // https://www.liciwang.com/upload/i01.pic.sogou.com/9aa89fd706dba7fe.jpg
        // https://www.liciwang.com/upload/i03.pictn.sogoucdn.com/42fecd35e9fff842.jpg
        "/upload/i[0-9]*\\.pic[a-z]*\\.sogou(?:cdn)?\\.com/[0-9a-f]+\\.",
        "$\\.dmcdn\\.net/",
        "$i\\.mycdn\\.me/",
        "$[^/]*\/(?:images|thumbs)\/(?:[-0-9A-Za-z_]{68,}|[-0-9A-Za-z_]{63}|[-0-9A-Za-z_]{56})\.jpg$",
        // http://silviomessina.pw/images/best-25-lesley-ann-brandt-ideas-on-pinterest__aHR0cHM6Ly9zLW1lZGlhLWNhY2hlLWFrMC5waW5pbWcuY29tLzczNngvZDAvZTYvN2QvZDBlNjdkMTI2Mzg4NThkYmFkMTgwZWFhNmU5ZTQ0NjMtLWxlc2xleS1hbm4tYnJhbmR0LWdheS1jZWxlYnJpdGllcy5qcGc=.jpg
        //"$[^/]*/(?:images|thumbs)/[^/]*__[a-zA-Z0-9=]{100,}(?:\.[^/.]*)?$",
        "$k[0-9]*\.kn3\.net/",
        "$file\\.osen\\.co\\.kr/",
        "$img\\.etoday\\.co\\.kr/",
        // https://m.munhwanews.com/news/photo/201707/67316_115010_229.png
        "$\\.com/news/photo/[0-9]{6}/[0-9]+_[0-9]+_[0-9]+\.[^/.]*$",
        "$(?:\\.co)?\\.kr/+(?:.*/)?news/photo/[0-9]{6}/[0-9]+_[0-9]+_[0-9]+\.[^/.]*$",
        "$pds\\.exblog\\.jp/",
        "$blogimg\\.goo\\.ne\\.jp/",
        "$img\\.kb-cdn\\.com/",
        "$img\\.rasset\\.ie/",
        "$\\.xhcdn\\.com/.*_1000\.[^/.]*$",
        // https://ocdn.eu/pulscms-transforms/1/inbktkpTURBXy82OWI0MWIxYmU3MmI2MTJiZjllNTk0MjMzZGYwYmFlMC5qcGeSlQLNA8AAwsOVAgDNA8DCww
        "$ocdn\\.eu/pulscms-transforms/",
        // https://s020.radikal.ru/i711/1410/bb/c715ee5a35e0.jpg
        "$s[0-9]*\\.radikal\\.ru/",
        // http://img1.bdbphotos.com/images/orig/b/t/bt8xdoj38zo43jzx.jpg?skj2io4l
        "$img[0-9]*\\.bdbphotos\\.com/",
        "$\\.fs\\.quoracdn\\.com/",
        "$images-cdn\\.9gag\\.com/",
        "$\\.bellazon\\.com/",
        "$img\\.theqoo\\.net/",
        "$pp\\.vk\\.me/",
        "$thebarchive\\.com/",
        "$i\\.4pcdn\\.org/",
        "$cdn\\.4archive\\.org/",
        "$celebposter\\.com/",
        "$image\\.tmdb\\.org/",
        "$favim\\.com/",
        "$wfiles\\.brothersoft\\.com/",
        "$\\.gravatar",
        "$selca\\.kastden\\.org/",
        "$cache\\.desktopnexus\\.com/",
        "$dncache-mauganscorp\\.netdna-ssl\\.com/",
        "$cache[0-9]*\\.asset-cache\\.net/",
        "$fap\\.to/",
        "$bobx\\.com/",
        "$/thumbs/[0-9]{5,}x/[0-9]{5,}\.jpg$",
        "$t.imgbox.com/",
        "$i.imgbox.com/",
        "$(?:steamcdn-[a-z].akamaihd.net|cdn.akamai.steamstatic.com)/steamcommunity/public/images/avatars/.*_full",
        "$external-preview\.redd\.it/",
        "$media\.148apps\.com/",
        "$(?:amazonaws\.com/)?image\.blingee\.com/",
        "$media[0-9]*\.tenor\.com/",
        "$(?:getwallpapers|wallpapertag)\.com/wallpaper/full/",
        "$hdqwalls.com/",
        "$file[0-9]*\\.instiz\\.net/",
        "$media\\.istockphoto\\.com/",
        // http://5b0988e595225.cdn.sohucs.com/images/20190422/f5f0e092a084430aa0e2ce31ad35feea.jpeg
        // http://5b0988e595225.cdn.sohucs.com/images/20190425/4ec7221c9f4047b89ba4d9770ef85135.jpeg
        "$[0-9a-f]+\\.cdn\\.sohucs\\.com/images/+[0-9]{8}\/+[0-9a-f]+\.[^/.]*(?:[?#].*)?$",
        // https://im.vsco.co/aws-us-west-2/b68580/74476754/5c7624c5ef3068500ce138b2/vsco5c7624c5c4814.jpg?w=342&dpr=1 (gets automatically redirected)
        //"$im\\.vsco\\.co/",
        // https://file.mk.co.kr/meet/neds/2015/04/image_readtop_2015_344513_14286618521866802.jpg
        "$file\\.mk\\.co\\.kr/meet/neds/[0-9]{4}/[0-9]{2}/image_readtop_[0-9]{4}_[0-9]+_[0-9]{10,}\\.[^/.]*$",
        // https://thumb.named.com/normal/resize/origin/file/photo/editor/1806/9f95a04042dd42948a7463ed2ff023c8_chGTZOx2fYUGbnoH.jpg
        "$thumb\\.named\\.com/normal/resize/origin/file/",
        // http://cdn.hasshe.com/img/s/Bz3yXHh0V8j9yjho5dsGugHaE8.jpg
        "$cdn\.hasshe\.com/img/s/",
        // https://avatars.mds.yandex.net/get-pdb/199965/2ca0ee78-ec22-464a-a7f1-164a9f332954/orig
        "$avatars\.mds\.yandex\.net\/.*\/orig$",
        // https://media.licdn.com/media-proxy/ext?w=800&h=800&hash=VK0UKoB6kYGsO4w%2Fpmwvhw5BQiQ%3D&ora=1%2CaFBCTXdkRmpGL2lvQUFBPQ%2CxAVta5g-0R6jnR0VjBEo47yOvkC28AlESo-TEHO-WiCt56LhFWrqccXAIO_w8whVZ1pjjWNAAY21PG-2TY7Nf9W9KMEM-PDlJJHmM1VTJww4gg
        "$media\.licdn\.com/media-proxy/ext[?]",
        //      http://msright.ctoalik.ru/images/xd41YGmrxMTui3fnDtV3muJvRiqfw_6roSPsQXgQKlpPg7n3zBAT1xnAdcA.jpg
        //             http://www.v1zg.ru/images/qaqWhKSO-I2AuNmq_v8lAtxoNSWj_Jf6qkOGJ9-foDtmAKWuOMsMh1OYFP4.jpg
        // http://oflzep-822.pornovp.info/images/ejdZSY7vEPIyePhC8nQBnN6xZa_zW1yGeX8RcGzQsbZcLtz4qGgCldn3nUE.jpg
        //     http://www.s69pornotv.info/images/zjBpeM6_3oIIgm3-BICKt4jJyBZKcoio9PXQN2G5rlaZl4Sgl3C6anR-dbA.jpg
        "$/images/[-a-zA-Z0-9_]{59}\\.jpg$",
        "$\\.userapi\\.com/",
    ].join("\n");
    
    function getlink(src) {
        if (!src)
            return src;
        
        var protocol_split = src.split("://");
        if (!protocol_split)
            return src;
        var protocol = protocol_split[0];
        if (!protocol_split[1])
            return src;
        var splitted = protocol_split[1].split("/");
        var domain = splitted[0];
        var domain_nowww = domain.replace(/^www\./, "");
        var domain_nosub = domain.replace(/^.*\.([^.]*\.[^.]*)$/, "$1");
        
        if (domain === "image.baidu.com") {
            return decodeURIComponent(src.replace(/.*?[?&]objurl=([^&]*).*/, "$1"));
        }
        
        if (domain.match(/\.google\./)) {
            //var newsrc = decodeURIComponent(src.replace(/.*?[?&]imgurl=([^&]*).*/, "$1"));
            var newsrc = src.replace(/^[a-z]+:\/\/[^/]*\/imgres.*?[?&]imgurl=([^&]*).*/, "$1");
            if (newsrc !== src)
                return decodeURIComponent(newsrc);
            newsrc = src.replace(/^[a-z]+:\/\/[^/]*\/url.*?[?&]url=([^&]*).*/, "$1");
            if (newsrc !== src)
                return decodeURIComponent(newsrc);
        }
        
        if (domain.match(/\.images\.search\.yahoo\./)) {
            return "http://" + decodeURIComponent(src.replace(/.*?[?&]imgurl=([^&]*).*/, "$1"));
        }
        
        if (domain.match(/bing\.com/)) {
            return decodeURIComponent(src.replace(/.*?[?&]mediaurl=([^&]*).*?$/, "$1"));
        }
        
        if (domain.match(/proxy\.duckduckgo\.com/)) {
            return decodeURIComponent(src.replace(/.*?\/iu\/.*?[?&]u=([^&]*).*?$/, "$1"));
        }
        
        if (domain.match(/browse\.startpage\.com/)) {
            return decodeURIComponent(src.replace(/.*?show_picture\.pl.*?[?&]oiu=([^&]*).*?$/, "$1"));
        }
        
        if (domain.match(/^(?:www\.)?yandex.ru/) && src.match(/\/images\/search.*[?&]img_url=/)) {
            return decodeURIComponent(src.replace(/.*?[?&]img_url=([^&]*).*?$/, "$1"));
        }
        
        if (domain.match(/^(?:www\.)?metager\.org/)) {
            return decodeURIComponent(src.replace(/.*?picture\?url=([^&]*).*/, "$1"));
        }
        
        return src;
    }
    
    function black_image(selector, el, is_regex) {
        var black_el = el;
        if (selector && selector.image) {
            black_el = el.querySelector(selector.image);
        }
        var style = "brightness(0%)";
        if (is_regex)
            style = "brightness(10%)";
        black_el.style.filter = style;
    }
    
    function process_el(selector, el, newurl, regexes) {
        var imu = unsafeWindow.imu_variable;
        //console.log(newurl);
        
        if (!newurl.match(/^https?:/)) {
            black_image(selector, el, true);
            return [0, 1];
        }

        try {
            //console_log(newurl);
            if (imu(newurl, {
                    fill_object: false,
                    exclude_problems: [],
                    cb: function() {},
                    do_request: function() {}
                    }) !== newurl) {
                //console_log("IMU");
                //el.style.filter = "brightness(0%)";
                black_image(selector, el);
                return [1, 0];
            }
        } catch (e) {
            console_log("Couldn't run IMU on: " + newurl);
            console.log(el);
            console.dir(e);
        }
        
        for (var i = 0; i < regexes.length; i++) {
            if (newurl.match(regexes[i])) {
                /*el.style.display = "none";
                el.style.visibility = "hidden";*/
                //el.style.filter = "brightness(0%)";
                black_image(selector, el, true);
                return [0, 1];
            }
        }
        
        //console.log(newurl);
        return [0, 0];
    }
    
    function apply(data) {
        var lines = data.split("\n")
        var regexes = [];
        lines.forEach((line) => {
            if (line.replace(/\s+/g, "") !== "")
                regexes.push(new RegExp(line.replace(/^[$]/, "^[a-z]+://[^/]*")));
        });
        //console_log(regexes);
        
        var total = 0;
        var replaced = 0;
        var cant = 0;
        if (document.location.host.indexOf("duckduckgo.com") >= 0) {
            var items = DDG.duckbar.initialTab.view.views.items;
            //console.log(items);
            total += items.length;
            items.forEach((item) => {
                var amount = process_el(null, item.$el[0], item.model.image, regexes);
                replaced += amount[0];
                cant += amount[1];
            });
        }
        selectors.forEach((selector) => {
            document.querySelectorAll(selector.parent).forEach((el) => {
                var link;
                
                if (selector.link.length > 0)
                    link = el.querySelector(selector.link);
                else
                    link = el;
                
                if (!link)
                    return;
                total++;
                var url = link.href;
                var can_replace = true;
                if (link.tagName === "IMG") {
                    url = link.src;
                    can_replace = false;
                }
                console.log(url);
                var newurl = getlink(url);
                if (!newurl)
                    return;
                if (can_replace)
                    link.href = newurl;
                var amount = process_el(selector, el, newurl, regexes);
                replaced += amount[0];
                cant += amount[1];
            });
        });
        
        function percent(x, y) {
            return parseInt(x / y * 100 * 1000) / 1000;
        }
        console.log(replaced + "/" + cant + "/(" + (replaced + cant) + ")/" + total + " (replaced: " + percent(replaced, total) + "%, can't: " + percent(cant, total) +"%, both: " + percent(cant + replaced, total) + "%)");
    }
    
    var already_processed = [];
    function do_preprocess() {
        selectors.forEach((selector) => {
            if (!selector.preprocess)
                return;

            document.querySelectorAll(selector.parent).forEach((el) => {
                if (already_processed.indexOf(el) < 0) {
                    selector.preprocess(el);
                    already_processed.push(el);
                }
            });
        });
    }
    
    function replacelink(a) {
        if (!a || !a.href)
            return;
        var oldhref = a.href;
        if (!oldhref.match(/^https?:\/\//))
            return;
        var newhref = getlink(oldhref);
        if (oldhref !== newhref) {
            //console_log(oldhref);
            //console_log(newhref);
            a.href = newhref;
        }
    }
    
    function replacelinks() {
        var links = document.querySelectorAll("a");
        if (links) {
            links.forEach(replacelink);
        }
        
        if (document.location.href.indexOf("bing.com/") < 0) {
            var observer = new MutationObserver(function(mutations) {
                mutations.forEach(function(mutation) {
                    if (mutation.type === "attributes" &&
                        mutation.target.tagName === "A" &&
                        mutation.attributeName === "href") {
                        replacelink(mutation.target);
                    }
                });
                do_preprocess();
            });
            observer.observe(document.documentElement, {
                attributes: true,
                characterData: false,
                childList: true,
                subtree: true,
                //attributeOldValue: true,
                characterDataOldValue: false
            });
        }
    }
    
    function create_textarea() {
        var container = document.createElement("div");
        container.style.zIndex = 9999999;
        container.style.position = "fixed";
        container.style.top = "0";
        container.style.right = "0";
        var ta = document.createElement("textarea");
        ta.value = defaults;
        var button = document.createElement("button");
        button.innerHTML = "Apply";
        button.onclick = function() {
            console.dir(ta);
            apply(ta.value);
        }
        container.appendChild(ta);
        container.appendChild(button);
        document.body.appendChild(container);
        console_log(container);
    }
    
    function load_script() {
        unsafeWindow.imu_variable = null;
        //unsafeWindow.module = {exports: {}};

        //var script_src = "https://gitcdn.xyz/repo/qsniyg/maxurl/master/userscript.user.js";
        //var script_src = "https://rawgit.com/qsniyg/maxurl/master/userscript.user.js";
        var script_src = "https://github.com/qsniyg/maxurl/raw/master/userscript.user.js";
        GM_xmlhttpRequest({
            url: script_src,
            method: "GET",
            onload: function(resp) {
                if (resp.readyState === 4) {
                    if (/^[a-z]+:\/\/[^/]*yandex\.[a-z]+\//.test(document.location.href)) {
                        // this doesn't work
                        //eval(resp.responseText);
                    } else {
                        var script = document.createElement("script");
                        script.innerHTML = resp.responseText;
                        document.body.appendChild(script);
                        console.log(script);
                        //eval(resp.responseText);
                    }
                    create_textarea();
                }
            }
        });
    }
    
    replacelinks();
    load_script();
    //create_textarea();
})();