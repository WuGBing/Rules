// ==UserScript==
// @name         Youtube No Autoplay - Disable "Up Next"
// @namespace    YoutubeNoAutoplay
// @version      2.97
// @description  Disable annoying autoplay button
// @author       yakumo_ran
// @match        *://www.youtube.com/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

function ModernCookieBased() {
    var name = 'PREF'
    var disableAutoplay = '&f5=30000'
    var match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
    if (match[2].includes('f5=20000') == true) {
        var newstr = match[2].replace(/f5=20000/, "f5=30000");
        document.cookie = 'PREF=' + newstr + ';  path=/; domain=.youtube.com';
    } else if (match[2].includes('f5=30000') == false) {
        document.cookie = 'PREF=' + match[2] + disableAutoplay + ';  path=/; domain=.youtube.com';
    }
}
function gensokyo() {
    "use strict";
    function yakumo(shikigami) {
        if (shikigami.hasAttribute("checked") == true) {
            shikigami.click();
            //setTimeout(ModernCookieBased, 3000);
        }
    }
    function yukari() {
    var ran = document.getElementById("toggle"),
        chen = document.getElementById("toggleButton"),
        youkai = document.getElementById("improved-toggle"),
        nekomata = document.getElementById("autoplay-checkbox");
        if (ran != null) {
            yakumo(ran);
        } else if (chen != null) {
            yakumo(chen);
        } else if (youkai != null) {
            yakumo(youkai);
        } else if (nekomata != null) {
            yakumo(nekomata);
        } else {
            setTimeout(yukari, 3000);
        }
    }
    setTimeout(yukari, 3000);
};
window.addEventListener("yt-navigate-finish", gensokyo);
window.addEventListener("spfdone", gensokyo);
gensokyo();
