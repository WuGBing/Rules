// ==UserScript==
// @name         斗鱼免登陆
// @namespace    https://greasyfork.org/
// @version      1.0.0
// @description  斗鱼免登陆看蓝光，需切换到html5播放器。
// @author       smzh369
// @match        *://www.douyu.com/*
// @grant        none
// @require      http://code.jquery.com/jquery-1.7.2.min.js
// ==/UserScript==
(function() {
  $(document).ready(function(){
    var storage=window.localStorage;
    var recordTime = storage.getItem('rateRecordTime_h5p_room');
    var recordObj = JSON.parse(recordTime);
    console.log(recordObj);
    recordObj.v = -888888;
    recordTime = JSON.stringify(recordObj);
    storage.setItem('rateRecordTime_h5p_room',recordTime);
  });
})();