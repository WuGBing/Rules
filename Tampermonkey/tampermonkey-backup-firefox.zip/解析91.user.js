// ==UserScript==
// @name         解析91
// @version      1.2.1
// @description  次数是无限的，但精力是有限的。
// @author       shopkeeperV
// @include      *://*91p*n.com/*
// @include      https://www.vlogdownloader.com/*
// @include      https://www.dmd.dog/*
// @namespace    https://greasyfork.org/users/150069
// @require      https://code.jquery.com/jquery-1.12.4.min.js
// ==/UserScript==
(function() {
    "use strict";
    //当前网址
    var thisSite = window.location.href;

    //91详情页
    if (/view_video/.test(thisSite) && !(/vlogdownloader|view_video_hd|dmd\.dog/.test(thisSite))) {
        var newTd = '<td style="position:relative;width:50px;">' +
            '<div style="position:absolute;left:0px;top:0px;z-index:999;"><table id="newTable"></table></div></td>';
        var btn1 = '<tr><td><b id="btn1" style="font-size:35px;cursor:pointer;color:#FFFF00;">①</b></td></tr>';
        var btn2 = '<tr><td><b id="btn2" style="font-size:35px;cursor:pointer;color:#FFFF00;">②</b></td></tr>';
        var btn3with4 = '<div style="margin-bottom:10px;font-size:20px;font-weight:bold;color:#FFFF00;">' +
            '<b id="btn3" style="border-style:solid;border-width:1px;cursor:pointer;">点我复制标题并下载</b>&nbsp;&nbsp;&nbsp;' +
            '<b id="btn4" style="border-style:solid;border-width:1px;cursor:pointer;">说明</b></div>';
        var msg = '<div id="msg" style="font-size:20px;font-weight:bold;color:#FFFF00;cursor:default;">' +
            '使用本插件可在已登陆的情况下无限播放和下载<br/>' +
            '未登陆用户可点击左侧的解析按钮播放<br/>' +
            '由于下载地址跨域，下载视频不能自动重命名，如有需要请手动修改</div>';
        $("#container_video>table td:first").after(newTd);
        $("#newTable").append(btn1, btn2);
        $("#containersearch").append(btn3with4, msg);
        $("#msg").hide();
        //解析1
        $("#btn1").click(function() {
            window.open("https://www.vlogdownloader.com/#" + thisSite);
        });
        //解析2
        $("#btn2").click(function() {
            window.open("https://www.dmd.dog/#" + thisSite);
        });
        //复制标题并下载
        $("#btn3").click(function() {
            if (document.getElementById("player_one_html5_api") !== null) {
                var title = $("#viewvideo-title")[0].innerText;
                var director = $("#videodetails-content>a:eq(0)")[0].innerText;
                var input = document.createElement("input");
                input.value = title + "-" + director;
                document.body.appendChild(input);
                input.select();
                document.execCommand("Copy");
                input.style.display = "none";
                window.open($("#player_one_html5_api source")[0].src);
            } else window.alert("请先登陆或使用解析");
        });
        //说明
        $("#btn4").hover(function() {
            $("#msg").show();
        }, function() {
            $("#msg").hide();
        });
    }

    //vLog主页
    else if (/vlogdownloader.*view/.test(thisSite)) {
        $("#vlog").submit();
    }

    //vLog播放页
    else if (/vlogdownloader.*html/.test(thisSite)) {
        //模态框背景固定
        $("#exampleModal").attr("data-backdrop", "static");
        $(".btn.btn-primary:eq(1)").click();
    }

    //vlog错误页
    else if (/vlogdownloader.*code=403/.test(thisSite)) {
        window.history.back();
    }

    //dmd播放页
    else if (/dmd\.dog.*view/.test(thisSite)) {
        $("#dmd-search").click();
    }

    //无限观看
    if (!/vlogdownloader|dmd\.dog/.test(thisSite)) {
        document.cookie = "watch_times=0";
    }
})();