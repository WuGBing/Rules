// ==UserScript==
// @name         虎牙免登陆（修复版）
// @namespace    https://greasyfork.org/
// @version      1.1.2
// @description  虎牙免登陆看高清
// @author       smzh369
// @match        *://www.huya.com/*
// @grant        none
// @require      http://code.jquery.com/jquery-1.7.2.min.js
// ==/UserScript==

(function() {
  $(document).ready(function(){
    $('#player-login-tip-wrap').remove();
    VPlayer.prototype.checkLogin(true);
  });
})();
